export const SUITS = ["s", "h", "d", "c"] as const;
export type Suit = (typeof SUITS)[number];
export type Rank = 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14;

export interface Card {
  rank: Rank;
  suit: Suit;
}

export type Street = "preflop" | "flop" | "turn" | "river";
export type Difficulty = "casual" | "regular" | "pro";
export type TableSize = 2 | 4 | 6;
export type Speed = "slow" | "normal" | "fast";

export type Phase =
  | "lobby"
  | "dealing"
  | "acting"
  | "runout"
  | "showdown"
  | "between"
  | "busted"
  | "winner";

export type ActionKind = "fold" | "check" | "call" | "bet" | "raise" | "allin";

export interface Action {
  kind: ActionKind;
  /** Absolute chips committed this street after the action (bet/raise-to). */
  amount?: number;
}

export interface Player {
  id: string;
  seat: number;
  name: string;
  isHuman: boolean;
  personalityId: string | null;
  stack: number;
  hole: Card[] | null;
  betStreet: number;
  committed: number;
  folded: boolean;
  allIn: boolean;
  busted: boolean;
  showed: boolean;
  vpipHand: boolean;
  pfrHand: boolean;
}

export interface Pot {
  amount: number;
  eligible: string[];
}

export interface ActionRecord {
  handId: number;
  street: Street;
  playerId: string;
  name: string;
  kind: ActionKind | "blind" | "ante" | "deal" | "win" | "return";
  amount?: number;
  text: string;
}

export interface ShownHand {
  playerId: string;
  hole: Card[];
  handName: string;
  rank: number;
  five: Card[];
}

export interface PotAward {
  amount: number;
  winnerIds: string[];
  handName: string | null;
}

export interface ShowdownResult {
  pots: PotAward[];
  shown: ShownHand[];
  uncontested?: string;
}

export interface Config {
  seats: TableSize;
  smallBlind: number;
  bigBlind: number;
  buyInBb: number;
  difficulty: Difficulty;
  speed: Speed;
  playerName: string;
  autoMuck: boolean;
}

export interface PlayerStats {
  hands: number;
  vpip: number;
  pfr: number;
  threeBet: number;
  aggro: number;
  calls: number;
  folds: number;
  showdowns: number;
  wtsd: number;
  wins: number;
}

export interface GameState {
  config: Config;
  phase: Phase;
  handId: number;
  street: Street;
  button: number;
  deck: Card[];
  board: Card[];
  burns: Card[];
  players: Player[];
  currentBet: number;
  lastFullRaise: number;
  toAct: string[];
  actorId: string | null;
  lastAggressorId: string | null;
  log: ActionRecord[];
  result: ShowdownResult | null;
  rngSeed: number;
  sessionNet: number;
  sessionHands: number;
  playerStats: Record<string, PlayerStats>;
  lastStartStacks: Record<string, number>;
  preflopRaises: number;
  streetAggressions: number;
  handContested: boolean;
}

export type HandCategory =
  | "high-card"
  | "pair"
  | "two-pair"
  | "trips"
  | "straight"
  | "flush"
  | "full-house"
  | "quads"
  | "straight-flush";

export interface EvaluatedHand {
  rank: number;
  category: HandCategory;
  name: string;
  five: Card[];
}

export interface LegalSet {
  canFold: boolean;
  canCheck: boolean;
  canCall: boolean;
  callAmount: number;
  canBet: boolean;
  canRaise: boolean;
  minBet: number;
  minRaiseTo: number;
  maxTo: number;
  canAllIn: boolean;
  allInAmount: number;
}

export interface BoardTexture {
  paired: boolean;
  trips: boolean;
  monotone: boolean;
  twoTone: boolean;
  wet: boolean;
  connected: boolean;
  broadwayHeavy: boolean;
  dry: boolean;
  flushPossible: boolean;
  straightPossible: boolean;
}
