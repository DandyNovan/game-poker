import type { GameState } from "./types";
import { describeHole, legalActions, potTotal, positionName } from "./engine";
import { analyzeBoard, bestHand, drawInfo, madeBucket } from "./hand";
import { holeLabel } from "./cards";
import { monteCarloEquity, potOdds, spr } from "./equity";

export interface CoachReport {
  hole: string;
  made: string;
  bucket: string;
  position: string;
  street: string;
  pot: number;
  toCall: number;
  potOdds: number;
  spr: number;
  equity: number;
  outs: number;
  draws: string[];
  texture: string[];
  advice: string;
  samples: number;
}

export function coachReport(state: GameState): CoachReport | null {
  try {
    return buildReport(state);
  } catch {
    return null;
  }
}

function buildReport(state: GameState): CoachReport | null {
  const hero = state.players.find((p) => p.id === "hero");
  if (!hero?.hole || hero.hole.length < 2) return null;
  const legal = legalActions(state, state.actorId === "hero" ? "hero" : undefined);
  const toCall = state.actorId === "hero" ? legal.callAmount : Math.max(0, state.currentBet - hero.betStreet);
  const pot = potTotal(state);
  const nOpp = Math.max(
    1,
    state.players.filter((p) => !p.folded && !p.busted && p.id !== "hero").length,
  );
  const board = state.board;
  const made = board.length >= 3 ? bestHand(hero.hole, board) : null;
  const draws = board.length >= 3 ? drawInfo(hero.hole, board) : null;
  const texture = analyzeBoard(board);
  const eq =
    board.length >= 3
      ? monteCarloEquity(hero.hole, board, nOpp, 140, (state.rngSeed ^ 0x9e3779b9) >>> 0 || 1)
      : monteCarloEquity(hero.hole, [], nOpp, 100, (state.rngSeed ^ 0x85ebca6b) >>> 0 || 1);
  const odds = potOdds(toCall, pot);
  const stackSpr = spr(hero.stack, Math.max(1, pot));
  const bucket = board.length >= 3 ? madeBucket(hero.hole, board) : "air";
  const pos = positionName(state, hero.seat);
  const drawLabels: string[] = [];
  if (draws?.flushDraw) drawLabels.push(`Flush draw (${draws.flushOuts} outs)`);
  if (draws?.oesd) drawLabels.push("Open-ended straight");
  if (draws?.gutshot) drawLabels.push("Gutshot");
  if (draws?.comboDraw) drawLabels.push("Combo draw");
  if (draws && draws.overcards) drawLabels.push(`${draws.overcards} overcard${draws.overcards > 1 ? "s" : ""}`);

  const tex: string[] = [];
  if (texture.dry) tex.push("Dry");
  if (texture.wet) tex.push("Wet");
  if (texture.paired) tex.push("Paired");
  if (texture.monotone) tex.push("Monotone");
  if (texture.twoTone) tex.push("Two-tone");
  if (texture.connected) tex.push("Connected");
  if (texture.broadwayHeavy) tex.push("Broadway");

  const advice = advise({
    eq: eq.equity,
    odds,
    toCall,
    bucket,
    draws: drawLabels,
    spr: stackSpr,
    canCheck: legal.canCheck,
    street: state.street,
    pos,
  });

  return {
    hole: describeHole(hero.hole) || holeLabel(hero.hole[0]!, hero.hole[1]!),
    made: made?.name ?? "Preflop",
    bucket,
    position: pos,
    street: state.street,
    pot,
    toCall,
    potOdds: odds,
    spr: stackSpr,
    equity: eq.equity,
    outs: draws?.outs ?? 0,
    draws: drawLabels,
    texture: tex,
    advice,
    samples: eq.samples,
  };
}

function advise(a: {
  eq: number;
  odds: number;
  toCall: number;
  bucket: string;
  draws: string[];
  spr: number;
  canCheck: boolean;
  street: string;
  pos: string;
}): string {
  if (a.toCall <= 0) {
    if (a.bucket === "nuts" || a.bucket === "strong") {
      return a.spr < 2
        ? "Nut advantage, short SPR — look to get it in."
        : "Strong made hand. Bet for value; size up on wet textures.";
    }
    if (a.draws.length) {
      return `Equity ${pct(a.eq)} with draws. ${a.pos === "BTN" || a.pos === "CO" ? "In position, a stab is reasonable." : "Out of position, checking and realizing is cleaner."}`;
    }
    if (a.eq > 0.55) return "Range advantage. A continuation bet keeps you in the driver's seat.";
    return a.canCheck
      ? "No initiative. Check and keep the pot small unless the board is excellent for a bluff."
      : "Proceed carefully.";
  }
  if (a.eq >= a.odds + 0.08) {
    return `Getting the right price (${pct(a.odds)} pot odds vs ${pct(a.eq)} equity). Call, or raise for value if they are capped.`;
  }
  if (a.eq >= a.odds - 0.02 && a.draws.length) {
    return `Drawing with ${pct(a.eq)} equity, need about ${pct(a.odds)}. Call if implied odds are there.`;
  }
  if (a.bucket === "top-pair" && a.odds <= 0.35) {
    return "Top pair, modest ask. Call and reassess the next street.";
  }
  if (a.eq < a.odds - 0.08 && a.bucket === "air") {
    return `Behind (${pct(a.eq)} vs ${pct(a.odds)} needed). Fold unless you have a specific bluff.`;
  }
  return `Close spot. Equity ${pct(a.eq)}, pot odds ${pct(a.odds)}, SPR ${a.spr.toFixed(1)}. Prefer the line that keeps your range balanced.`;
}

function pct(n: number): string {
  return `${Math.round(n * 100)}%`;
}
