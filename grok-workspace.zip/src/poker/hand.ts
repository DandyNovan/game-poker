import type { BoardTexture, Card, EvaluatedHand, HandCategory, Rank } from "./types";
import { RANK_LABEL, sameCard } from "./cards";

const CAT_ORDER: HandCategory[] = [
  "high-card",
  "pair",
  "two-pair",
  "trips",
  "straight",
  "flush",
  "full-house",
  "quads",
  "straight-flush",
];

const CAT_NAME: Record<HandCategory, string> = {
  "high-card": "High card",
  pair: "Pair",
  "two-pair": "Two pair",
  trips: "Three of a kind",
  straight: "Straight",
  flush: "Flush",
  "full-house": "Full house",
  quads: "Four of a kind",
  "straight-flush": "Straight flush",
};

function pack(category: HandCategory, kickers: number[]): number {
  let v = CAT_ORDER.indexOf(category);
  const k = kickers.slice(0, 5);
  while (k.length < 5) k.push(0);
  for (const x of k) v = (v << 4) | (x & 15);
  return v;
}

function pickByRank(cards: Card[], rank: number, n: number): Card[] {
  return cards.filter((c) => c.rank === rank).slice(0, n);
}

function highestNot(cards: Card[], banned: number[], n: number): Card[] {
  const rest = cards
    .filter((c) => !banned.includes(c.rank))
    .slice()
    .sort((a, b) => b.rank - a.rank);
  const out: Card[] = [];
  const seen = new Set<string>();
  for (const c of rest) {
    const id = `${c.rank}${c.suit}`;
    if (seen.has(id)) continue;
    seen.add(id);
    out.push(c);
    if (out.length >= n) break;
  }
  return out;
}

function uniqueSortedRanks(cards: Card[]): number[] {
  const set = new Set(cards.map((c) => c.rank));
  return [...set].sort((a, b) => b - a);
}

/** High card of a 5-card straight, or 0. Ace is 14 and also 1 (wheel). */
export function straightHigh(ranks: number[]): number {
  const set = new Set(ranks);
  if (set.has(14)) set.add(1);
  for (let h = 14; h >= 5; h--) {
    if (set.has(h) && set.has(h - 1) && set.has(h - 2) && set.has(h - 3) && set.has(h - 4)) {
      return h;
    }
  }
  return 0;
}

function straightCards(cards: Card[], high: number): Card[] {
  const want = high === 5 ? [5, 4, 3, 2, 14] : [high, high - 1, high - 2, high - 3, high - 4];
  const used: Card[] = [];
  for (const r of want) {
    const c = cards.find((x) => x.rank === r && !used.some((u) => sameCard(u, x)));
    if (c) used.push(c);
  }
  return used;
}

function nameOf(category: HandCategory, kickers: number[]): string {
  const r = (n: number) => RANK_LABEL[n as Rank] ?? String(n);
  switch (category) {
    case "straight-flush":
      return kickers[0] === 14 ? "Royal flush" : `Straight flush, ${r(kickers[0]!)} high`;
    case "quads":
      return `Four of a kind, ${r(kickers[0]!)}s`;
    case "full-house":
      return `Full house, ${r(kickers[0]!)}s full of ${r(kickers[1]!)}s`;
    case "flush":
      return `Flush, ${r(kickers[0]!)} high`;
    case "straight":
      return `Straight, ${r(kickers[0]!)} high`;
    case "trips":
      return `Three of a kind, ${r(kickers[0]!)}s`;
    case "two-pair":
      return `Two pair, ${r(kickers[0]!)}s and ${r(kickers[1]!)}s`;
    case "pair":
      return `Pair of ${r(kickers[0]!)}s`;
    default:
      return `${r(kickers[0]!)} high`;
  }
}

export function evaluate(cards: Card[]): EvaluatedHand {
  if (cards.length < 5 || cards.length > 7) {
    throw new Error(`evaluate expects 5–7 cards, got ${cards.length}`);
  }
  const sorted = cards.slice().sort((a, b) => b.rank - a.rank || a.suit.localeCompare(b.suit));
  const byRank = new Map<number, Card[]>();
  const bySuit = new Map<string, Card[]>();
  for (const c of sorted) {
    const rr = byRank.get(c.rank) ?? [];
    rr.push(c);
    byRank.set(c.rank, rr);
    const ss = bySuit.get(c.suit) ?? [];
    ss.push(c);
    bySuit.set(c.suit, ss);
  }
  const groups = [...byRank.entries()].sort((a, b) => b[1].length - a[1].length || b[0] - a[0]);

  let flushSuit: string | null = null;
  let flushCards: Card[] = [];
  for (const [s, list] of bySuit) {
    if (list.length >= 5 && list.length > flushCards.length) {
      flushSuit = s;
      flushCards = list.slice().sort((a, b) => b.rank - a.rank);
    }
  }

  if (flushSuit) {
    const sfHigh = straightHigh(flushCards.map((c) => c.rank));
    if (sfHigh) {
      const five = straightCards(flushCards, sfHigh);
      const kickers = [sfHigh];
      return {
        rank: pack("straight-flush", kickers),
        category: "straight-flush",
        name: nameOf("straight-flush", kickers),
        five,
      };
    }
  }

  const quads = groups.find((g) => g[1].length === 4);
  if (quads) {
    const kicker = highestNot(sorted, [quads[0]], 1);
    const five = [...quads[1], ...kicker];
    const kickers = [quads[0], kicker[0]?.rank ?? 0];
    return { rank: pack("quads", kickers), category: "quads", name: nameOf("quads", kickers), five };
  }

  const tripsList = groups.filter((g) => g[1].length >= 3);
  const pairList = groups.filter((g) => g[1].length === 2);
  if (tripsList.length >= 1 && (pairList.length >= 1 || tripsList.length >= 2)) {
    const tripRank = tripsList[0]![0];
    let pairRank: number;
    if (tripsList.length >= 2) pairRank = tripsList[1]![0];
    else pairRank = pairList.sort((a, b) => b[0] - a[0])[0]![0];
    const five = [...pickByRank(sorted, tripRank, 3), ...pickByRank(sorted, pairRank, 2)];
    const kickers = [tripRank, pairRank];
    return {
      rank: pack("full-house", kickers),
      category: "full-house",
      name: nameOf("full-house", kickers),
      five,
    };
  }

  if (flushCards.length >= 5) {
    const five = flushCards.slice(0, 5);
    const kickers = five.map((c) => c.rank);
    return { rank: pack("flush", kickers), category: "flush", name: nameOf("flush", kickers), five };
  }

  const sHigh = straightHigh(uniqueSortedRanks(sorted));
  if (sHigh) {
    const five = straightCards(sorted, sHigh);
    const kickers = [sHigh];
    return {
      rank: pack("straight", kickers),
      category: "straight",
      name: nameOf("straight", kickers),
      five,
    };
  }

  if (tripsList.length >= 1) {
    const tripRank = tripsList[0]![0];
    const kick = highestNot(sorted, [tripRank], 2);
    const five = [...pickByRank(sorted, tripRank, 3), ...kick];
    const kickers = [tripRank, ...kick.map((c) => c.rank)];
    return { rank: pack("trips", kickers), category: "trips", name: nameOf("trips", kickers), five };
  }

  const pairs = groups.filter((g) => g[1].length === 2).sort((a, b) => b[0] - a[0]);
  if (pairs.length >= 2) {
    const hi = pairs[0]![0];
    const lo = pairs[1]![0];
    const kick = highestNot(sorted, [hi, lo], 1);
    const five = [...pickByRank(sorted, hi, 2), ...pickByRank(sorted, lo, 2), ...kick];
    const kickers = [hi, lo, kick[0]?.rank ?? 0];
    return {
      rank: pack("two-pair", kickers),
      category: "two-pair",
      name: nameOf("two-pair", kickers),
      five,
    };
  }

  if (pairs.length === 1) {
    const pr = pairs[0]![0];
    const kick = highestNot(sorted, [pr], 3);
    const five = [...pickByRank(sorted, pr, 2), ...kick];
    const kickers = [pr, ...kick.map((c) => c.rank)];
    return { rank: pack("pair", kickers), category: "pair", name: nameOf("pair", kickers), five };
  }

  const five = sorted.slice(0, 5);
  const kickers = five.map((c) => c.rank);
  return {
    rank: pack("high-card", kickers),
    category: "high-card",
    name: nameOf("high-card", kickers),
    five,
  };
}

export function bestHand(hole: Card[], board: Card[]): EvaluatedHand | null {
  const cards = [...hole, ...board];
  if (cards.length < 5) return null;
  return evaluate(cards);
}

export function categoryIndex(c: HandCategory): number {
  return CAT_ORDER.indexOf(c);
}

export function chenScore(a: Card, b: Card): number {
  const scoreHigh = (r: number) => {
    if (r === 14) return 10;
    if (r === 13) return 8;
    if (r === 12) return 7;
    if (r === 11) return 6;
    if (r === 10) return 5;
    return r / 2;
  };
  const hi = Math.max(a.rank, b.rank);
  const lo = Math.min(a.rank, b.rank);
  let s = scoreHigh(hi);
  if (a.rank === b.rank) {
    s = Math.max(s * 2, 5);
  } else {
    if (a.suit === b.suit) s += 2;
    const gap = hi - lo - 1;
    if (gap === 0) s += 1;
    else if (gap === 1) s -= 1;
    else if (gap === 2) s -= 2;
    else if (gap === 3) s -= 4;
    else s -= 5;
    if (gap === 0 && hi < 12) s += 1;
    if (hi < 14 && lo >= 10) s += 1;
  }
  return Math.max(0, Math.ceil(s));
}

export function analyzeBoard(board: Card[]): BoardTexture {
  if (board.length < 3) {
    return {
      paired: false,
      trips: false,
      monotone: false,
      twoTone: false,
      wet: false,
      connected: false,
      broadwayHeavy: false,
      dry: true,
      flushPossible: false,
      straightPossible: false,
    };
  }
  const suits = new Map<string, number>();
  const ranks = new Map<number, number>();
  for (const c of board) {
    suits.set(c.suit, (suits.get(c.suit) ?? 0) + 1);
    ranks.set(c.rank, (ranks.get(c.rank) ?? 0) + 1);
  }
  const suitCounts = [...suits.values()].sort((a, b) => b - a);
  const rankCounts = [...ranks.values()].sort((a, b) => b - a);
  const unique = [...ranks.keys()].sort((a, b) => a - b);
  const paired = (rankCounts[0] ?? 0) >= 2;
  const trips = (rankCounts[0] ?? 0) >= 3;
  const monotone = (suitCounts[0] ?? 0) >= 3 && board.length === 3
    ? (suitCounts[0] ?? 0) === 3
    : (suitCounts[0] ?? 0) >= 4;
  const twoTone = (suitCounts[0] ?? 0) >= 2 && (suitCounts[1] ?? 0) >= 2;
  const flushPossible = (suitCounts[0] ?? 0) >= 3;
  let connected = false;
  for (let i = 0; i < unique.length; i++) {
    for (let j = i + 1; j < unique.length; j++) {
      if (unique[j]! - unique[i]! <= 4) connected = true;
    }
  }
  const wheelish = unique.includes(14) && unique.some((r) => r <= 5);
  const straightPossible = connected || wheelish;
  const broadwayHeavy = board.filter((c) => c.rank >= 10).length >= 2;
  const wet = flushPossible && straightPossible;
  const dry = !paired && (suitCounts[0] ?? 0) <= 2 && !connected;
  return {
    paired,
    trips,
    monotone,
    twoTone,
    wet,
    connected,
    broadwayHeavy,
    dry,
    flushPossible,
    straightPossible,
  };
}

export interface DrawInfo {
  flushDraw: boolean;
  flushOuts: number;
  oesd: boolean;
  gutshot: boolean;
  overcards: number;
  outs: number;
  outCards: Card[];
  comboDraw: boolean;
}

export function drawInfo(hole: Card[], board: Card[], dead: Card[] = []): DrawInfo {
  const known = [...hole, ...board, ...dead];
  const made = board.length >= 3 ? evaluate([...hole, ...board]) : null;
  const madeIdx = made ? categoryIndex(made.category) : -1;
  const remaining: Card[] = [];
  for (const suit of ["s", "h", "d", "c"] as const) {
    for (let r = 2; r <= 14; r++) {
      const c = { rank: r as Rank, suit };
      if (!known.some((k) => sameCard(k, c))) remaining.push(c);
    }
  }

  const suitCounts = new Map<string, number>();
  for (const c of [...hole, ...board]) suitCounts.set(c.suit, (suitCounts.get(c.suit) ?? 0) + 1);
  let flushDraw = false;
  let flushOuts = 0;
  for (const [s, n] of suitCounts) {
    if (n === 4) {
      flushDraw = true;
      flushOuts = remaining.filter((c) => c.suit === s).length;
    }
  }

  const ranks = [...new Set([...hole, ...board].map((c) => c.rank))];
  const sNow = board.length >= 3 ? straightHigh(ranks) : 0;
  let oesd = false;
  let gutshot = false;
  if (!sNow && board.length >= 3) {
    let eight = 0;
    let four = 0;
    for (const c of remaining) {
      if (straightHigh([...ranks, c.rank])) {
        const left = remaining.filter((x) => x.rank === c.rank).length;
        if (left >= 4) eight += 1;
        else four += 1;
      }
    }
    const uniqueImprovers = new Set(
      remaining.filter((c) => straightHigh([...ranks, c.rank])).map((c) => c.rank),
    ).size;
    if (uniqueImprovers >= 2) oesd = true;
    else if (uniqueImprovers === 1) gutshot = true;
    void eight;
    void four;
  }

  const boardMax = board.reduce((m, c) => Math.max(m, c.rank), 0);
  const overcards = hole.filter((c) => c.rank > boardMax && !board.some((b) => b.rank === c.rank)).length;

  const outCards: Card[] = [];
  if (board.length >= 3) {
    for (const c of remaining) {
      const next = evaluate([...hole, ...board, c]);
      if (categoryIndex(next.category) > madeIdx) outCards.push(c);
      else if (made && next.rank > made.rank) outCards.push(c);
    }
  }

  const outs = outCards.length;
  return {
    flushDraw,
    flushOuts,
    oesd,
    gutshot,
    overcards,
    outs,
    outCards,
    comboDraw: flushDraw && (oesd || gutshot),
  };
}

export type MadeBucket =
  | "nuts"
  | "strong"
  | "top-pair"
  | "middle-pair"
  | "weak-pair"
  | "ace-high"
  | "air";

export function madeBucket(hole: Card[], board: Card[]): MadeBucket {
  if (board.length < 3) return "air";
  const ev = evaluate([...hole, ...board]);
  const boardEv = board.length >= 5 ? evaluate(board) : null;
  if (ev.category === "straight-flush" || ev.category === "quads") return "nuts";
  if (ev.category === "full-house" || ev.category === "flush" || ev.category === "straight") {
    return boardEv && ev.rank >= boardEv.rank + 64 ? "nuts" : "strong";
  }
  if (ev.category === "trips") return "strong";
  if (ev.category === "two-pair") {
    const holePair = hole[0] && hole[1] && hole[0].rank === hole[1].rank;
    return holePair ? "strong" : "top-pair";
  }
  if (ev.category === "pair") {
    const pairRank = ev.five[0]!.rank;
    const boardRanks = board.map((c) => c.rank).sort((a, b) => b - a);
    const top = boardRanks[0] ?? 0;
    const second = boardRanks[1] ?? 0;
    const pocket = hole[0] && hole[1] && hole[0].rank === hole[1].rank ? hole[0].rank : 0;
    if (pocket && pocket > top) return "strong";
    if (pairRank === top) return "top-pair";
    if (pairRank === second || (pocket && pocket >= second)) return "middle-pair";
    return "weak-pair";
  }
  const hi = Math.max(hole[0]?.rank ?? 0, hole[1]?.rank ?? 0);
  if (hi === 14) return "ace-high";
  return "air";
}

export const BUCKET_STRENGTH: Record<MadeBucket, number> = {
  nuts: 0.99,
  strong: 0.84,
  "top-pair": 0.66,
  "middle-pair": 0.48,
  "weak-pair": 0.34,
  "ace-high": 0.22,
  air: 0.08,
};
