import assert from "node:assert/strict";
import { test } from "node:test";
import { parseCards } from "./cards.ts";
import { chenScore, evaluate } from "./hand.ts";

test("royal flush beats quads", () => {
  const royal = evaluate(parseCards("As Ks Qs Js Ts 2d 3c"));
  const quads = evaluate(parseCards("Ah Ad Ac As Kh Kd 9c"));
  assert.equal(royal.category, "straight-flush");
  assert.ok(royal.rank > quads.rank);
  assert.match(royal.name, /Royal/);
});

test("wheel straight flush", () => {
  const wheel = evaluate(parseCards("As 2s 3s 4s 5s Kh Kd"));
  assert.equal(wheel.category, "straight-flush");
  assert.ok(!wheel.name.includes("Royal"));
});

test("full house ranking", () => {
  const acesFull = evaluate(parseCards("Ah Ad Ac Ks Kh 2c 3d"));
  const kingsFull = evaluate(parseCards("Kh Kd Kc As Ah 2c 3d"));
  assert.equal(acesFull.category, "full-house");
  assert.ok(acesFull.rank > kingsFull.rank);
});

test("trips without a pair is three of a kind", () => {
  const trips = evaluate(parseCards("Ah Ad Ac Ks 9h 7c 2d"));
  assert.equal(trips.category, "trips");
});

test("trips plus pair is a full house", () => {
  const fh = evaluate(parseCards("Ah Ad Ac Ks Kh 7c 2d"));
  assert.equal(fh.category, "full-house");
});

test("wheel loses to six-high straight", () => {
  const wheel = evaluate(parseCards("Ah 2d 3c 4s 5h 9c 9d"));
  const six = evaluate(parseCards("2h 3d 4c 5s 6h 9c 9d"));
  assert.equal(wheel.category, "straight");
  assert.equal(six.category, "straight");
  assert.ok(six.rank > wheel.rank);
});

test("flush beats straight", () => {
  const flush = evaluate(parseCards("Ah 9h 7h 4h 2h Kc Kd"));
  const straight = evaluate(parseCards("9s 8d 7c 6h 5s 2c 2d"));
  assert.ok(flush.rank > straight.rank);
});

test("pair kickers", () => {
  const a = evaluate(parseCards("Ah Ad Kc Qs 9h 3c 2d"));
  const b = evaluate(parseCards("As Ac Kh Js 9d 3s 2h"));
  assert.ok(a.rank > b.rank);
});

test("chen AA is premium", () => {
  const [a, b] = parseCards("Ah Ad");
  assert.ok(chenScore(a!, b!) >= 10);
});
