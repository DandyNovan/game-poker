import type { Difficulty } from "./types";

export interface Personality {
  id: string;
  name: string;
  tagline: string;
  /** Opening looseness 0–1 (higher = more hands). */
  loose: number;
  /** Postflop bet frequency. */
  aggression: number;
  /** Willingness to bluff. */
  bluff: number;
  /** Call-down frequency with medium hands. */
  sticky: number;
  /** How much they respect position. */
  positional: number;
  /** Size pot more polar (high) vs small-merged. */
  polar: number;
  /** Talkativeness 0–1. */
  talk: number;
  /** Color token for seat pip. */
  tone: "bone" | "pine" | "ink" | "clay" | "mist";
}

export const PERSONALITIES: Personality[] = [
  {
    id: "vesper",
    name: "Vesper",
    tagline: "Tight-aggressive, range-aware",
    loose: 0.22,
    aggression: 0.78,
    bluff: 0.26,
    sticky: 0.32,
    positional: 0.9,
    polar: 0.7,
    talk: 0.12,
    tone: "bone",
  },
  {
    id: "raka",
    name: "Raka",
    tagline: "Trappy mid-stakes reg",
    loose: 0.26,
    aggression: 0.52,
    bluff: 0.18,
    sticky: 0.48,
    positional: 0.7,
    polar: 0.35,
    talk: 0.28,
    tone: "pine",
  },
  {
    id: "juno",
    name: "Juno",
    tagline: "High-volume pressure",
    loose: 0.42,
    aggression: 0.88,
    bluff: 0.46,
    sticky: 0.4,
    positional: 0.55,
    polar: 0.8,
    talk: 0.55,
    tone: "clay",
  },
  {
    id: "nadir",
    name: "Nadir",
    tagline: "Nit. Waits for premiums",
    loose: 0.12,
    aggression: 0.62,
    bluff: 0.08,
    sticky: 0.18,
    positional: 0.85,
    polar: 0.45,
    talk: 0.08,
    tone: "ink",
  },
  {
    id: "dimas",
    name: "Dimas",
    tagline: "LAG, isolation specialist",
    loose: 0.36,
    aggression: 0.74,
    bluff: 0.34,
    sticky: 0.38,
    positional: 0.8,
    polar: 0.6,
    talk: 0.4,
    tone: "mist",
  },
];

export function difficultyTune(p: Personality, d: Difficulty): Personality {
  if (d === "pro") {
    return {
      ...p,
      loose: p.loose * 0.92,
      aggression: Math.min(0.92, p.aggression + 0.06),
      bluff: p.bluff * 0.95 + 0.04,
      sticky: p.sticky * 0.85,
      positional: Math.min(1, p.positional + 0.08),
    };
  }
  if (d === "casual") {
    return {
      ...p,
      loose: Math.min(0.55, p.loose + 0.12),
      aggression: p.aggression * 0.82,
      bluff: p.bluff * 0.7,
      sticky: Math.min(0.7, p.sticky + 0.18),
      positional: p.positional * 0.7,
    };
  }
  return p;
}

export function pickRoster(seats: number): Personality[] {
  const order = ["vesper", "dimas", "raka", "juno", "nadir"];
  const n = Math.max(0, seats - 1);
  return order
    .slice(0, n)
    .map((id) => PERSONALITIES.find((p) => p.id === id)!)
    .filter(Boolean);
}

export const LINES: Record<string, Partial<Record<string, string[]>>> = {
  fold: {
    low: ["Fold.", "Out."],
    mid: ["Not this one.", "I muck."],
    high: ["Nah.", "Too thin.", "You can have it."],
  },
  check: {
    low: ["Check."],
    mid: ["Check.", "Seeing a card."],
    high: ["Check it down?", "I'll peek."],
  },
  call: {
    low: ["Call."],
    mid: ["Call.", "I'm in."],
    high: ["Call. Let's see it.", "Alright, call."],
  },
  raise: {
    low: ["Raise."],
    mid: ["Raising.", "I make it more."],
    high: ["Let's play a pot.", "Pressure."],
  },
  allin: {
    low: ["All-in."],
    mid: ["I'm all-in."],
    high: ["All of it.", "Shove."],
  },
};
