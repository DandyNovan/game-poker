import type { Action, GameState, Player } from "./types";
import { chenScore, madeBucket, drawInfo, analyzeBoard, BUCKET_STRENGTH, bestHand } from "./hand";
import { legalActions, potTotal, positionName } from "./engine";
import { monteCarloEquity, potOdds, spr } from "./equity";
import { PERSONALITIES, difficultyTune, type Personality } from "./personalities";
import { mulberry32 } from "./cards";

function roundTo(n: number, step: number): number {
  if (step <= 0) return Math.round(n);
  return Math.max(step, Math.round(n / step) * step);
}

function pick<T>(rng: () => number, a: T, b: T, pA: number): T {
  return rng() < pA ? a : b;
}

function personalityOf(p: Player): Personality {
  return PERSONALITIES.find((x) => x.id === p.personalityId) ?? PERSONALITIES[0]!;
}

function rfiThreshold(pos: string): number {
  if (pos.startsWith("UTG") || pos === "HJ") return 9;
  if (pos === "CO") return 7;
  if (pos === "BTN" || pos.startsWith("BTN")) return 5.5;
  if (pos === "SB") return 7;
  return 8;
}

function openSize(state: GameState, pos: string, stack: number, polar: number): number {
  const bb = state.config.bigBlind;
  let x = 2.3;
  if (pos === "SB") x = 3.2;
  if (pos.startsWith("UTG")) x = 2.5;
  x += polar * 0.3;
  const limpers = state.players.filter(
    (p) => !p.folded && !p.busted && p.betStreet === bb && p.id !== state.actorId,
  ).length;
  if (limpers) x += 0.8 * limpers;
  return Math.min(stack, roundTo(x * bb, state.config.smallBlind));
}

function betSize(state: GameState, me: Player, polar: number, wet: boolean, street: string): number {
  const pot = potTotal(state);
  const legal = legalActions(state, me.id);
  let frac = wet ? 0.72 : 0.42;
  if (street === "flop" && !wet) frac = 0.33;
  if (street === "turn") frac = wet ? 0.75 : 0.55;
  if (street === "river") frac = polar > 0.6 ? 0.95 : 0.66;
  const raw = pot * frac;
  const to = (state.currentBet === 0 ? 0 : me.betStreet) + raw;
  const stepped = roundTo(Math.max(legal.minBet, to === 0 ? legal.minBet : raw), state.config.smallBlind);
  if (state.currentBet === 0) {
    return Math.min(legal.maxTo, Math.max(legal.minBet, stepped));
  }
  const raiseTo = Math.max(legal.minRaiseTo, me.betStreet + stepped);
  return Math.min(legal.maxTo, raiseTo);
}

function shove(legal: ReturnType<typeof legalActions>, me: Player): Action {
  return { kind: "allin", amount: me.betStreet + me.stack };
}

function raiseTo(legal: ReturnType<typeof legalActions>, to: number, me: Player): Action {
  const capped = Math.min(legal.maxTo, Math.max(legal.minRaiseTo || legal.minBet, to));
  if (capped >= me.betStreet + me.stack) return shove(legal, me);
  if (legal.canBet && legal.callAmount === 0) return { kind: "bet", amount: capped };
  if (legal.canRaise) return { kind: "raise", amount: capped };
  if (legal.canAllIn) return shove(legal, me);
  if (legal.canCall) return { kind: "call", amount: legal.callAmount };
  if (legal.canCheck) return { kind: "check" };
  return { kind: "fold" };
}

function passive(legal: ReturnType<typeof legalActions>): Action {
  if (legal.canCheck) return { kind: "check" };
  if (legal.canCall) return { kind: "call", amount: legal.callAmount };
  if (legal.canAllIn && legal.callAmount >= legal.allInAmount) return { kind: "allin" };
  return { kind: "fold" };
}

export function chooseAction(state: GameState, seed = 1): Action {
  const me = state.players.find((p) => p.id === state.actorId);
  if (!me || !me.hole || me.hole.length < 2) return { kind: "fold" };
  const legal = legalActions(state, me.id);
  const rng = mulberry32((seed ^ (state.handId * 997) ^ me.seat * 13) >>> 0 || 1);
  const pers = difficultyTune(personalityOf(me), state.config.difficulty);
  const difficulty = state.config.difficulty;

  if (difficulty === "casual" && rng() < 0.1) {
    return noisy(legal, rng);
  }

  if (state.street === "preflop") return preflop(state, me, legal, pers, rng);
  return postflop(state, me, legal, pers, rng);
}

function noisy(legal: ReturnType<typeof legalActions>, rng: () => number): Action {
  const options: Action[] = [];
  if (legal.canCheck) options.push({ kind: "check" });
  if (legal.canCall) options.push({ kind: "call", amount: legal.callAmount });
  if (legal.canBet) options.push({ kind: "bet", amount: legal.minBet });
  if (legal.canRaise) options.push({ kind: "raise", amount: legal.minRaiseTo });
  if (legal.canFold) options.push({ kind: "fold" });
  return options[Math.floor(rng() * options.length)] ?? { kind: "fold" };
}

function preflop(
  state: GameState,
  me: Player,
  legal: ReturnType<typeof legalActions>,
  pers: Personality,
  rng: () => number,
): Action {
  const hole = me.hole!;
  const chen = chenScore(hole[0]!, hole[1]!);
  const pos = positionName(state, me.seat);
  const bb = state.config.bigBlind;
  const stackBb = me.stack / bb;
  const raises = state.preflopRaises;
  const pot = potTotal(state);
  const toCall = legal.callAmount;
  const odds = potOdds(toCall, pot);
  const inBlinds = pos === "SB" || pos === "BB";

  // Short-stack shove/fold
  if (stackBb <= 14 && (chen >= (raises === 0 ? 6 : 9) || (chen >= 8 && stackBb <= 8))) {
    if (legal.canAllIn || legal.canRaise || legal.canBet) return shove(legal, me);
  }

  if (raises === 0) {
    const thresh = rfiThreshold(pos) * (1.18 - pers.loose);
    if (chen >= thresh) {
      const to = openSize(state, pos, me.betStreet + me.stack, pers.polar);
      return raiseTo(legal, me.betStreet + to, me);
    }
    if (pos === "BB" && legal.canCheck) return { kind: "check" };
    if (pos === "SB" && chen >= thresh - 2 && pers.loose > 0.3 && legal.canCall) {
      return { kind: "call", amount: legal.callAmount };
    }
    if (legal.canCheck) return { kind: "check" };
    return { kind: "fold" };
  }

  // Facing a raise
  const threeThresh = 10.5 - pers.loose * 3;
  const fourThresh = 11.2 - pers.loose * 1.5;
  if (raises >= 2) {
    if (chen >= fourThresh) {
      if (stackBb <= 40 || chen >= 12) return shove(legal, me);
      return raiseTo(legal, Math.min(legal.maxTo, state.currentBet * 2.2), me);
    }
    if (chen >= 10 && toCall / pot < 0.55 && pers.sticky > 0.35 && legal.canCall) {
      return { kind: "call", amount: legal.callAmount };
    }
    if (legal.canCheck) return { kind: "check" };
    return { kind: "fold" };
  }

  // vs one raise: 3-bet / call / fold
  const ip = pos === "BTN" || pos === "CO" || pos === "BB";
  if (chen >= threeThresh || (chen >= threeThresh - 1.5 && pers.aggression > 0.7 && rng() < pers.bluff)) {
    const to = roundTo(state.currentBet * (inBlinds ? 3.2 : 2.6), state.config.smallBlind);
    return raiseTo(legal, to, me);
  }
  const defend = (ip ? 6 : 7.5) - pers.loose * 4;
  const priced = toCall <= bb * 4 || odds <= 0.32;
  if (chen >= defend && priced && legal.canCall) {
    if (rng() < pers.sticky + 0.25) return { kind: "call", amount: legal.callAmount };
  }
  if (pos === "BB" && chen >= defend - 1.5 && odds <= 0.36 && legal.canCall) {
    return { kind: "call", amount: legal.callAmount };
  }
  if (legal.canCheck) return { kind: "check" };
  return { kind: "fold" };
}

function postflop(
  state: GameState,
  me: Player,
  legal: ReturnType<typeof legalActions>,
  pers: Personality,
  rng: () => number,
): Action {
  const hole = me.hole!;
  const board = state.board;
  const nOpp = Math.max(1, state.players.filter((p) => !p.folded && !p.busted && p.id !== me.id).length);
  const samples = state.config.difficulty === "pro" ? 160 : state.config.difficulty === "regular" ? 80 : 36;
  const eq = monteCarloEquity(hole, board, nOpp, samples, (state.rngSeed ^ me.seat * 7919) >>> 0 || 1).equity;
  const bucket = madeBucket(hole, board);
  const draws = drawInfo(hole, board);
  const texture = analyzeBoard(board);
  const pot = potTotal(state);
  const toCall = legal.callAmount;
  const odds = potOdds(toCall, pot);
  const stackSpr = spr(me.stack, Math.max(1, pot));
  const made = bestHand(hole, board);
  const strength = Math.max(eq, BUCKET_STRENGTH[bucket]);
  const facing = toCall > 0;
  const lastToAct = state.toAct.length <= 1;
  const drawStrength =
    (draws.comboDraw ? 0.22 : 0) + (draws.flushDraw ? 0.16 : 0) + (draws.oesd ? 0.12 : 0) + (draws.gutshot ? 0.05 : 0);

  if (facing) {
    const commit = strength > 0.78 || (strength > 0.62 && stackSpr < 2.2);
    if (commit && (legal.canRaise || legal.canAllIn)) {
      if (stackSpr <= 2.4 || bucket === "nuts") return shove(legal, me);
      return raiseTo(legal, betSize(state, me, pers.polar, texture.wet, state.street), me);
    }
    if (eq >= odds + (pers.sticky > 0.4 ? -0.02 : 0.04) || bucket === "strong" || bucket === "nuts") {
      return passive(legal);
    }
    if (drawStrength > 0.15 && eq + drawStrength * 0.5 >= odds - 0.03) {
      if (draws.comboDraw && pers.aggression > 0.65 && rng() < pers.bluff + 0.15 && legal.canRaise) {
        return raiseTo(legal, betSize(state, me, pers.polar, true, state.street), me);
      }
      return passive(legal);
    }
    const bluffRaise =
      lastToAct &&
      texture.dry &&
      pers.bluff > 0.2 &&
      rng() < pers.bluff * (state.street === "river" ? 0.35 : 0.5) &&
      toCall < pot * 0.7 &&
      (legal.canRaise || legal.canAllIn);
    if (bluffRaise) return raiseTo(legal, betSize(state, me, pers.polar, false, state.street), me);
    if (bucket === "top-pair" && rng() < pers.sticky && legal.canCall && odds <= 0.42) {
      return { kind: "call", amount: legal.callAmount };
    }
    if (legal.canCheck) return { kind: "check" };
    return { kind: "fold" };
  }

  // Not facing a bet
  const cbet =
    strength > 0.55 ||
    (texture.dry && lastToAct && rng() < pers.aggression) ||
    (drawStrength > 0.18 && rng() < pers.aggression) ||
    (bucket === "air" && texture.dry && lastToAct && rng() < pers.bluff);

  if (cbet && (legal.canBet || legal.canAllIn)) {
    if (bucket === "nuts" && stackSpr < 1.6) return shove(legal, me);
    const to = betSize(state, me, pers.polar, texture.wet, state.street);
    if (legal.canBet) {
      const amount = Math.min(legal.maxTo, Math.max(legal.minBet, to));
      if (amount >= me.stack && legal.canAllIn) return shove(legal, me);
      return { kind: "bet", amount };
    }
    return shove(legal, me);
  }

  if (legal.canCheck) return { kind: "check" };
  if (made && strength > 0.4 && legal.canCall) return { kind: "call", amount: legal.callAmount };
  return pick(rng, { kind: "check" as const }, { kind: "fold" as const }, legal.canCheck ? 1 : 0);
}

export function aiDelayMs(state: GameState): number {
  const speed = state.config.speed;
  const base = speed === "fast" ? 420 : speed === "slow" ? 1400 : 780;
  const legal = legalActions(state);
  const big = legal.callAmount > potTotal(state) * 0.5 || legal.minRaiseTo > potTotal(state);
  const spread = big ? 900 : 420;
  const jitter = ((state.handId * 17 + (state.actorId?.length ?? 1) * 13) % spread) - spread / 4;
  return Math.max(280, base + jitter + (state.config.difficulty === "pro" && big ? 400 : 0));
}
