import type { Card, Rank, Suit } from "./types";
import { SUITS } from "./types";

export const RANK_CHARS = "23456789TJQKA";
export const RANK_LABEL: Record<Rank, string> = {
  2: "2",
  3: "3",
  4: "4",
  5: "5",
  6: "6",
  7: "7",
  8: "8",
  9: "9",
  10: "10",
  11: "J",
  12: "Q",
  13: "K",
  14: "A",
};

export const SUIT_GLYPH: Record<Suit, string> = {
  s: "♠",
  h: "♥",
  d: "♦",
  c: "♣",
};

export const SUIT_NAME: Record<Suit, string> = {
  s: "spades",
  h: "hearts",
  d: "diamonds",
  c: "clubs",
};

export function isRed(suit: Suit): boolean {
  return suit === "h" || suit === "d";
}

export function cardId(c: Card): string {
  return `${RANK_LABEL[c.rank]}${c.suit}`;
}

export function parseCard(code: string): Card {
  const raw = code.trim();
  const rankChar = raw.length === 3 && raw.startsWith("10") ? "T" : raw[0]!.toUpperCase();
  const suitChar = (raw.length === 3 && raw.startsWith("10") ? raw[2] : raw[1])!.toLowerCase();
  const ri = RANK_CHARS.indexOf(rankChar);
  if (ri < 0) throw new Error(`Bad rank in ${code}`);
  if (!SUITS.includes(suitChar as Suit)) throw new Error(`Bad suit in ${code}`);
  return { rank: (ri + 2) as Rank, suit: suitChar as Suit };
}

export function parseCards(codes: string): Card[] {
  return codes
    .trim()
    .split(/\s+/)
    .filter(Boolean)
    .map(parseCard);
}

export function fullDeck(): Card[] {
  const deck: Card[] = [];
  for (const suit of SUITS) {
    for (let r = 2; r <= 14; r++) {
      deck.push({ rank: r as Rank, suit });
    }
  }
  return deck;
}

export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Unbiased Fisher–Yates. */
export function shuffle<T>(items: T[], rng: () => number): T[] {
  const arr = items.slice();
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    const tmp = arr[i]!;
    arr[i] = arr[j]!;
    arr[j] = tmp;
  }
  return arr;
}

export function sameCard(a: Card, b: Card): boolean {
  return a.rank === b.rank && a.suit === b.suit;
}

export function cardIn(list: Card[], c: Card): boolean {
  return list.some((x) => sameCard(x, c));
}

export function removeCards(deck: Card[], used: Card[]): Card[] {
  return deck.filter((c) => !cardIn(used, c));
}

export function holeLabel(a: Card, b: Card): string {
  const hi = a.rank >= b.rank ? a : b;
  const lo = a.rank >= b.rank ? b : a;
  if (hi.rank === lo.rank) return `${RANK_LABEL[hi.rank]}${RANK_LABEL[lo.rank]}`;
  const suited = hi.suit === lo.suit ? "s" : "o";
  return `${RANK_LABEL[hi.rank]}${RANK_LABEL[lo.rank]}${suited}`;
}

export function formatChips(n: number): string {
  const sign = n < 0 ? "-" : "";
  const v = Math.abs(Math.round(n));
  if (v >= 1_000_000) {
    const m = v / 1_000_000;
    return `${sign}${m >= 10 ? m.toFixed(1) : m.toFixed(2)}M`;
  }
  if (v >= 10_000) {
    const k = v / 1000;
    return `${sign}${k >= 100 ? Math.round(k) : k.toFixed(1)}k`;
  }
  return `${sign}${v.toLocaleString("en-US")}`;
}

export function formatBb(chips: number, bb: number): string {
  if (bb <= 0) return formatChips(chips);
  const x = chips / bb;
  const abs = Math.abs(x);
  const body = abs >= 100 ? abs.toFixed(0) : abs >= 10 ? abs.toFixed(1) : abs.toFixed(2);
  return `${x < 0 ? "-" : ""}${body} BB`;
}
