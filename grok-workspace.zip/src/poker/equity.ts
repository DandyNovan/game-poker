import type { Card } from "./types";
import { fullDeck, mulberry32, removeCards, shuffle } from "./cards";
import { evaluate } from "./hand";

export interface EquityResult {
  win: number;
  tie: number;
  lose: number;
  equity: number;
  samples: number;
}

/**
 * Monte Carlo equity for a hero hand vs N unknown opponent hands.
 * Ties split equally. Fast enough for live coach / Pro AI (~150 samples).
 */
export function monteCarloEquity(
  hole: Card[],
  board: Card[],
  nOpp: number,
  samples: number,
  seed: number,
  extraDead: Card[] = [],
): EquityResult {
  const dead = [...hole, ...board, ...extraDead];
  const base = removeCards(fullDeck(), dead);
  const needBoard = Math.max(0, 5 - board.length);
  const rng = mulberry32(seed || 1);
  let win = 0;
  let tie = 0;
  let lose = 0;
  const oppCount = Math.max(1, nOpp);

  for (let s = 0; s < samples; s++) {
    const deck = shuffle(base, rng);
    let i = 0;
    const opps: Card[][] = [];
    let ok = true;
    for (let o = 0; o < oppCount; o++) {
      if (i + 1 >= deck.length) {
        ok = false;
        break;
      }
      opps.push([deck[i]!, deck[i + 1]!]);
      i += 2;
    }
    if (!ok) continue;
    const runout = board.slice();
    for (let k = 0; k < needBoard; k++) {
      if (i >= deck.length) {
        ok = false;
        break;
      }
      runout.push(deck[i++]!);
    }
    if (!ok || runout.length < 5) continue;

    const hero = evaluate([...hole, ...runout]).rank;
    let bestOpp = -1;
    let tied = 0;
    for (const oh of opps) {
      const r = evaluate([...oh, ...runout]).rank;
      if (r > bestOpp) {
        bestOpp = r;
        tied = 1;
      } else if (r === bestOpp) tied += 1;
    }
    if (hero > bestOpp) win += 1;
    else if (hero === bestOpp) tie += 1 / (tied + 1);
    else lose += 1;
  }

  const n = win + tie + lose;
  return {
    win,
    tie,
    lose,
    equity: n ? (win + tie) / n : 0.5,
    samples: n,
  };
}

export function potOdds(toCall: number, pot: number): number {
  if (toCall <= 0) return 0;
  return toCall / (pot + toCall);
}

export function spr(stack: number, pot: number): number {
  if (pot <= 0) return 99;
  return stack / pot;
}
