import type {
  Action,
  ActionKind,
  ActionRecord,
  Card,
  Config,
  GameState,
  LegalSet,
  Player,
  PlayerStats,
  Pot,
  ShowdownResult,
  Street,
} from "./types";
import { cardId, fullDeck, holeLabel, mulberry32, shuffle } from "./cards";
import { bestHand, evaluate } from "./hand";
import { pickRoster } from "./personalities";

const emptyStats = (): PlayerStats => ({
  hands: 0,
  vpip: 0,
  pfr: 0,
  threeBet: 0,
  aggro: 0,
  calls: 0,
  folds: 0,
  showdowns: 0,
  wtsd: 0,
  wins: 0,
});

function clone<T>(s: T): T {
  return structuredClone(s);
}

function rngFrom(state: GameState): () => number {
  const rng = mulberry32(state.rngSeed || 1);
  // burn a few so consecutive hands diverge even with nearby seeds
  rng();
  rng();
  return rng;
}

function livePlayers(state: GameState): Player[] {
  return state.players.filter((p) => !p.busted);
}

function inHand(p: Player): boolean {
  return !p.busted && !p.folded;
}

function canAct(p: Player): boolean {
  return inHand(p) && !p.allIn && p.stack > 0;
}

function byId(state: GameState, id: string): Player | undefined {
  return state.players.find((p) => p.id === id);
}

function nextLiveSeat(state: GameState, from: number, step = 1): number {
  const n = state.players.length;
  for (let i = 1; i <= n; i++) {
    const seat = (from + i * step + n * 8) % n;
    const p = state.players[seat];
    if (p && !p.busted) return seat;
  }
  return from;
}

export function positionName(state: GameState, seat: number): string {
  const live = livePlayers(state);
  const n = live.length;
  if (n < 2) return "";
  const button = state.button;
  const order: string[] = [];
  if (n === 2) {
    return seat === button ? "BTN / SB" : "BB";
  }
  const sb = nextLiveSeat(state, button);
  const bb = nextLiveSeat(state, sb);
  if (seat === button) return "BTN";
  if (seat === sb) return "SB";
  if (seat === bb) return "BB";
  const names = n === 6 ? ["UTG", "HJ", "CO"] : n === 4 ? ["UTG", "CO"] : ["UTG"];
  let s = nextLiveSeat(state, bb);
  let i = 0;
  while (s !== button && i < 8) {
    if (s === seat) return names[Math.min(i, names.length - 1)] ?? "MP";
    s = nextLiveSeat(state, s);
    i += 1;
  }
  void order;
  return "MP";
}

function firstPreflopSeat(state: GameState): number {
  const live = livePlayers(state);
  if (live.length === 2) return state.button; // HU: SB/BTN acts first
  const sb = nextLiveSeat(state, state.button);
  const bb = nextLiveSeat(state, sb);
  return nextLiveSeat(state, bb);
}

function firstPostflopSeat(state: GameState): number {
  const live = livePlayers(state);
  if (live.length === 2) {
    return nextLiveSeat(state, state.button); // HU: BB first postflop
  }
  const sb = nextLiveSeat(state, state.button);
  let s = sb;
  for (let i = 0; i < state.players.length; i++) {
    const p = state.players[s]!;
    if (inHand(p) && !p.allIn) return s;
    s = nextLiveSeat(state, s);
  }
  return sb;
}

export function potTotal(state: GameState): number {
  return state.players.reduce((s, p) => s + p.committed, 0);
}

export function committedThisStreet(state: GameState): number {
  return state.players.reduce((s, p) => s + p.betStreet, 0);
}

function log(
  state: GameState,
  p: Player | null,
  kind: ActionRecord["kind"],
  text: string,
  amount?: number,
): void {
  state.log.push({
    handId: state.handId,
    street: state.street,
    playerId: p?.id ?? "",
    name: p?.name ?? "Table",
    kind,
    amount,
    text,
  });
  if (state.log.length > 240) state.log.splice(0, state.log.length - 240);
}

function commit(p: Player, toStreetTotal: number): number {
  const need = Math.max(0, toStreetTotal - p.betStreet);
  const put = Math.min(need, p.stack);
  p.stack -= put;
  p.betStreet += put;
  p.committed += put;
  if (p.stack === 0) p.allIn = true;
  return put;
}

function take(p: Player, amount: number): number {
  const put = Math.min(amount, p.stack);
  p.stack -= put;
  p.betStreet += put;
  p.committed += put;
  if (p.stack === 0) p.allIn = true;
  return put;
}

export function defaultConfig(partial?: Partial<Config>): Config {
  return {
    seats: 6,
    smallBlind: 50,
    bigBlind: 100,
    buyInBb: 100,
    difficulty: "pro",
    speed: "normal",
    playerName: "You",
    autoMuck: true,
    ...partial,
  };
}

export function newLobby(config?: Partial<Config>, seed?: number): GameState {
  const cfg = defaultConfig(config);
  return {
    config: cfg,
    phase: "lobby",
    handId: 0,
    street: "preflop",
    button: 0,
    deck: [],
    board: [],
    burns: [],
    players: [],
    currentBet: 0,
    lastFullRaise: cfg.bigBlind,
    toAct: [],
    actorId: null,
    lastAggressorId: null,
    log: [],
    result: null,
    rngSeed: seed ?? (Math.floor(Math.random() * 0xffffffff) || 1),
    sessionNet: 0,
    sessionHands: 0,
    playerStats: {},
    lastStartStacks: {},
    preflopRaises: 0,
    streetAggressions: 0,
    handContested: false,
  };
}

export function sitDown(state: GameState): GameState {
  const s = clone(state);
  const cfg = s.config;
  const buy = cfg.buyInBb * cfg.bigBlind;
  const roster = pickRoster(cfg.seats);
  const players: Player[] = [];
  players.push({
    id: "hero",
    seat: 0,
    name: cfg.playerName.trim() || "You",
    isHuman: true,
    personalityId: null,
    stack: buy,
    hole: null,
    betStreet: 0,
    committed: 0,
    folded: false,
    allIn: false,
    busted: false,
    showed: false,
    vpipHand: false,
    pfrHand: false,
  });
  for (let i = 0; i < cfg.seats - 1; i++) {
    const per = roster[i]!;
    players.push({
      id: per.id,
      seat: i + 1,
      name: per.name,
      isHuman: false,
      personalityId: per.id,
      stack: buy,
      hole: null,
      betStreet: 0,
      committed: 0,
      folded: false,
      allIn: false,
      busted: false,
      showed: false,
      vpipHand: false,
      pfrHand: false,
    });
  }
  s.players = players;
  s.playerStats = Object.fromEntries(players.map((p) => [p.id, emptyStats()]));
  s.button = Math.max(0, cfg.seats - 2);
  s.phase = "between";
  s.log = [];
  log(s, null, "deal", `Sat ${cfg.seats}-max · ${cfg.smallBlind}/${cfg.bigBlind} · ${cfg.difficulty}`);
  return startHand(s);
}

function resetPlayerForHand(p: Player): void {
  p.hole = null;
  p.betStreet = 0;
  p.committed = 0;
  p.folded = p.busted;
  p.allIn = false;
  p.showed = false;
  p.vpipHand = false;
  p.pfrHand = false;
  if (p.stack <= 0) {
    p.busted = true;
    p.folded = true;
  }
}

export function startHand(state: GameState): GameState {
  const s = clone(state);
  for (const p of s.players) {
    if (p.stack <= 0) p.busted = true;
    resetPlayerForHand(p);
  }
  const live = livePlayers(s);
  const hero = byId(s, "hero");
  if (!hero || hero.busted) {
    s.phase = "busted";
    s.actorId = null;
    return s;
  }
  if (live.length === 1) {
    s.phase = "winner";
    s.actorId = null;
    return s;
  }
  if (live.length < 2) {
    s.phase = "winner";
    return s;
  }

  s.handId += 1;
  s.sessionHands += 1;
  s.street = "preflop";
  s.board = [];
  s.burns = [];
  s.result = null;
  s.preflopRaises = 0;
  s.streetAggressions = 0;
  s.handContested = false;
  s.lastAggressorId = null;
  s.lastStartStacks = Object.fromEntries(s.players.map((p) => [p.id, p.stack]));
  for (const p of live) {
    const st = s.playerStats[p.id] ?? emptyStats();
    st.hands += 1;
    s.playerStats[p.id] = st;
  }

  s.button = nextLiveSeat(s, s.button);
  s.rngSeed = (Math.imul(s.rngSeed || 1, 1664525) + 1013904223) >>> 0 || 1;
  const rng = rngFrom(s);
  s.deck = shuffle(fullDeck(), rng);

  const sbSeat = live.length === 2 ? s.button : nextLiveSeat(s, s.button);
  const bbSeat = live.length === 2 ? nextLiveSeat(s, s.button) : nextLiveSeat(s, sbSeat);
  const sb = s.players[sbSeat]!;
  const bb = s.players[bbSeat]!;
  const sbPut = take(sb, s.config.smallBlind);
  const bbPut = take(bb, s.config.bigBlind);
  log(s, sb, "blind", `${sb.name} posts SB ${sbPut}`, sbPut);
  log(s, bb, "blind", `${bb.name} posts BB ${bbPut}`, bbPut);

  // deal 2 hole cards clockwise from SB
  let seat = sbSeat;
  for (let round = 0; round < 2; round++) {
    for (let i = 0; i < live.length; i++) {
      const p = s.players[seat]!;
      if (!p.busted) {
        const c = s.deck.pop();
        if (c) {
          p.hole = p.hole ? [...p.hole, c] : [c];
        }
      }
      seat = nextLiveSeat(s, seat);
    }
  }

  s.currentBet = Math.max(sb.betStreet, bb.betStreet);
  s.lastFullRaise = s.config.bigBlind;
  const first = firstPreflopSeat(s);
  s.toAct = buildToAct(s, first);
  s.phase = "dealing";
  s.actorId = s.toAct[0] ?? null;
  log(s, null, "deal", `Hand #${s.handId} · button ${s.players[s.button]?.name ?? ""}`);
  return s;
}

function buildToAct(state: GameState, firstSeat: number): string[] {
  const ids: string[] = [];
  let seat = firstSeat;
  for (let i = 0; i < state.players.length; i++) {
    const p = state.players[seat]!;
    if (canAct(p)) ids.push(p.id);
    seat = (seat + 1) % state.players.length;
  }
  return ids;
}

export function beginActing(state: GameState): GameState {
  const s = clone(state);
  if (s.phase !== "dealing" && s.phase !== "runout") return s;
  if (bettingClosed(s)) {
    return continueAfterBetting(s);
  }
  s.phase = "acting";
  s.actorId = s.toAct[0] ?? null;
  return s;
}

function bettingClosed(state: GameState): boolean {
  const live = state.players.filter(inHand);
  if (live.length <= 1) return true;
  const actors = live.filter(canAct);
  if (actors.length === 0) return true;
  if (state.toAct.length === 0) {
    const unmatched = actors.filter((p) => p.betStreet < state.currentBet);
    return unmatched.length === 0;
  }
  return false;
}

export function legalActions(state: GameState, playerId?: string): LegalSet {
  const id = playerId ?? state.actorId;
  const empty: LegalSet = {
    canFold: false,
    canCheck: false,
    canCall: false,
    callAmount: 0,
    canBet: false,
    canRaise: false,
    minBet: 0,
    minRaiseTo: 0,
    maxTo: 0,
    canAllIn: false,
    allInAmount: 0,
  };
  if (state.phase !== "acting" || !id) return empty;
  const p = byId(state, id);
  if (!p || !canAct(p) || state.toAct[0] !== id) return empty;

  const toCall = Math.max(0, state.currentBet - p.betStreet);
  const maxTo = p.betStreet + p.stack;
  const minBet = state.config.bigBlind;
  const minRaiseTo = state.currentBet + state.lastFullRaise;
  const canCheck = toCall === 0;
  const canCall = toCall > 0 && p.stack > 0;
  const canBet = toCall === 0 && p.stack > minBet;
  const canRaise = toCall > 0 && maxTo > state.currentBet && maxTo >= Math.min(minRaiseTo, maxTo);
  const raiseOk = toCall > 0 && p.stack > toCall && maxTo > state.currentBet;
  return {
    canFold: true,
    canCheck,
    canCall: canCall && toCall < p.stack,
    callAmount: Math.min(toCall, p.stack),
    canBet,
    canRaise: raiseOk && maxTo >= minRaiseTo,
    minBet: Math.min(minBet, p.stack),
    minRaiseTo: Math.min(minRaiseTo, maxTo),
    maxTo,
    canAllIn: p.stack > 0,
    allInAmount: p.stack,
  };
}

function trackVoluntarily(state: GameState, p: Player, kind: ActionKind, aggressive: boolean): void {
  const st = state.playerStats[p.id] ?? emptyStats();
  if (kind === "fold") st.folds += 1;
  if (kind === "call") st.calls += 1;
  if (aggressive) st.aggro += 1;
  if (state.street === "preflop") {
    if (kind !== "fold" && kind !== "check") {
      if (!p.vpipHand) {
        st.vpip += 1;
        p.vpipHand = true;
      }
    }
    if (aggressive) {
      if (!p.pfrHand) {
        st.pfr += 1;
        p.pfrHand = true;
      }
      if (state.preflopRaises >= 1) st.threeBet += 1;
    }
  }
  state.playerStats[p.id] = st;
}

export function applyAction(state: GameState, action: Action): GameState {
  const s = clone(state);
  if (s.phase !== "acting" || !s.actorId) return s;
  const p = byId(s, s.actorId);
  if (!p || !canAct(p)) return s;
  const legal = legalActions(s, p.id);

  const kind = action.kind;
  if (kind === "fold") {
    if (!legal.canFold) return s;
    p.folded = true;
    trackVoluntarily(s, p, "fold", false);
    log(s, p, "fold", `${p.name} folds`);
    s.toAct = s.toAct.filter((id) => id !== p.id);
  } else if (kind === "check") {
    if (!legal.canCheck) return s;
    log(s, p, "check", `${p.name} checks`);
    s.toAct = s.toAct.filter((id) => id !== p.id);
  } else if (kind === "call") {
    if (!legal.canCall && !(legal.canAllIn && legal.callAmount >= p.stack)) return s;
    const put = commit(p, s.currentBet);
    trackVoluntarily(s, p, p.allIn ? "allin" : "call", false);
    log(s, p, p.allIn ? "allin" : "call", p.allIn ? `${p.name} calls all-in ${put}` : `${p.name} calls ${put}`, put);
    s.toAct = s.toAct.filter((id) => id !== p.id);
  } else if (kind === "bet") {
    if (!legal.canBet && !legal.canAllIn) return s;
    const to = Math.max(legal.minBet, Math.min(action.amount ?? legal.minBet, legal.maxTo));
    const put = commit(p, to);
    const isFull = p.betStreet >= s.config.bigBlind;
    s.currentBet = p.betStreet;
    if (isFull) s.lastFullRaise = p.betStreet;
    s.lastAggressorId = p.id;
    s.streetAggressions += 1;
    trackVoluntarily(s, p, p.allIn ? "allin" : "bet", true);
    if (s.street === "preflop") s.preflopRaises += 1;
    log(s, p, p.allIn ? "allin" : "bet", p.allIn ? `${p.name} bets all-in ${put}` : `${p.name} bets ${put}`, put);
    reopen(s, p.id);
  } else if (kind === "raise") {
    if (!legal.canRaise && !legal.canAllIn) return s;
    const to = Math.max(legal.minRaiseTo, Math.min(action.amount ?? legal.minRaiseTo, legal.maxTo));
    const prev = s.currentBet;
    const put = commit(p, to);
    const inc = p.betStreet - prev;
    const full = inc >= s.lastFullRaise;
    s.currentBet = Math.max(s.currentBet, p.betStreet);
    if (full) s.lastFullRaise = inc;
    s.lastAggressorId = p.id;
    s.streetAggressions += 1;
    trackVoluntarily(s, p, p.allIn ? "allin" : "raise", true);
    if (s.street === "preflop") s.preflopRaises += 1;
    log(
      s,
      p,
      p.allIn ? "allin" : "raise",
      p.allIn ? `${p.name} shoves ${put}` : `${p.name} raises to ${p.betStreet}`,
      put,
    );
    if (full || p.betStreet > prev) reopen(s, p.id, full);
    else s.toAct = s.toAct.filter((id) => id !== p.id);
  } else if (kind === "allin") {
    const prev = s.currentBet;
    const put = take(p, p.stack);
    const newBet = p.betStreet;
    const inc = newBet - prev;
    s.currentBet = Math.max(s.currentBet, newBet);
    const fromZero = prev === 0;
    const full = fromZero ? newBet >= s.config.bigBlind : inc >= s.lastFullRaise;
    if (full) s.lastFullRaise = fromZero ? newBet : inc;
    if (newBet > prev) s.lastAggressorId = p.id;
    if (newBet > prev) s.streetAggressions += 1;
    trackVoluntarily(s, p, "allin", newBet > prev);
    if (s.street === "preflop" && newBet > prev) s.preflopRaises += 1;
    log(s, p, "allin", `${p.name} is all-in ${put}`, put);
    if (newBet > prev && full) reopen(s, p.id, true);
    else s.toAct = s.toAct.filter((id) => id !== p.id);
  }

  s.handContested = s.players.filter(inHand).length > 1;
  s.toAct = s.toAct.filter((id) => {
    const pl = byId(s, id);
    return pl && canAct(pl);
  });

  if (s.players.filter(inHand).length <= 1) {
    return finishUncontested(s);
  }
  if (bettingClosed(s)) {
    return continueAfterBetting(s);
  }
  s.actorId = s.toAct[0] ?? null;
  s.phase = "acting";
  return s;
}

function reopen(state: GameState, actorId: string, full = true): void {
  if (!full) {
    state.toAct = state.toAct.filter((id) => id !== actorId);
    return;
  }
  const ids: string[] = [];
  const actor = byId(state, actorId);
  if (!actor) return;
  let seat = (actor.seat + 1) % state.players.length;
  for (let i = 0; i < state.players.length; i++) {
    const p = state.players[seat]!;
    if (p.id !== actorId && canAct(p)) ids.push(p.id);
    seat = (seat + 1) % state.players.length;
  }
  state.toAct = ids;
}

function returnUncalled(state: GameState): void {
  const live = state.players.filter((p) => p.committed > 0);
  if (live.length === 0) return;
  const max = Math.max(...live.map((p) => p.committed));
  const second = Math.max(0, ...live.filter((p) => p.committed < max).map((p) => p.committed));
  const leaders = live.filter((p) => p.committed === max);
  if (leaders.length !== 1) return;
  const extra = max - Math.max(second, ...live.filter((p) => p.id !== leaders[0]!.id).map((p) => p.committed));
  if (extra > 0) {
    const p = leaders[0]!;
    p.committed -= extra;
    p.betStreet = Math.max(0, p.betStreet - extra);
    p.stack += extra;
    if (p.stack > 0) p.allIn = false;
    log(state, p, "return", `Uncalled ${extra} returned to ${p.name}`, extra);
  }
}

function continueAfterBetting(state: GameState): GameState {
  const live = state.players.filter(inHand);
  if (live.length <= 1) return finishUncontested(state);

  const actors = live.filter(canAct);
  const stillToMatch = actors.filter((p) => p.betStreet < state.currentBet);
  if (stillToMatch.length > 0) {
    state.toAct = stillToMatch.map((p) => p.id);
    state.actorId = state.toAct[0] ?? null;
    state.phase = "acting";
    return state;
  }

  for (const p of state.players) p.betStreet = 0;

  if (live.length === 1) return finishUncontested(state);

  const allLocked = actors.length <= 1;
  if (state.street === "river" || (allLocked && state.board.length === 5)) {
    return goShowdown(state);
  }
  if (allLocked) {
    state.phase = "runout";
    state.actorId = null;
    return state;
  }
  state.phase = "runout";
  state.actorId = null;
  return state;
}

export function dealNextStreet(state: GameState): GameState {
  const s = clone(state);
  if (s.phase !== "runout" && s.phase !== "dealing") return s;
  const live = s.players.filter(inHand);
  if (live.length <= 1) return finishUncontested(s);

  const burn = s.deck.pop();
  if (burn) s.burns.push(burn);

  if (s.street === "preflop") {
    const c1 = s.deck.pop();
    const c2 = s.deck.pop();
    const c3 = s.deck.pop();
    if (c1 && c2 && c3) s.board.push(c1, c2, c3);
    s.street = "flop";
    log(s, null, "deal", `Flop ${s.board.map(cardId).join(" ")}`);
  } else if (s.street === "flop") {
    const c = s.deck.pop();
    if (c) s.board.push(c);
    s.street = "turn";
    log(s, null, "deal", `Turn ${cardId(s.board[3]!)}`);
  } else if (s.street === "turn") {
    const c = s.deck.pop();
    if (c) s.board.push(c);
    s.street = "river";
    log(s, null, "deal", `River ${cardId(s.board[4]!)}`);
  } else {
    return goShowdown(s);
  }

  s.currentBet = 0;
  s.lastFullRaise = s.config.bigBlind;
  s.lastAggressorId = null;
  s.streetAggressions = 0;
  for (const p of s.players) p.betStreet = 0;

  const liveNow = s.players.filter(inHand);
  const actors = liveNow.filter(canAct);
  if (actors.length <= 1) {
    if (s.street === "river" || s.board.length === 5) return goShowdown(s);
    s.phase = "runout";
    s.actorId = null;
    return s;
  }

  const first = firstPostflopSeat(s);
  s.toAct = buildToAct(s, first);
  s.actorId = s.toAct[0] ?? null;
  s.phase = "acting";
  return s;
}

function finishUncontested(state: GameState): GameState {
  returnUncalled(state);
  const winner = state.players.find(inHand);
  if (!winner) {
    state.phase = "between";
    return state;
  }
  const pot = potTotal(state);
  winner.stack += pot;
  const st = state.playerStats[winner.id] ?? emptyStats();
  st.wins += 1;
  state.playerStats[winner.id] = st;
  if (winner.id === "hero") {
    const start = state.lastStartStacks[winner.id] ?? 0;
    state.sessionNet += winner.stack - start;
  } else {
    const hero = byId(state, "hero");
    if (hero) {
      const start = state.lastStartStacks.hero ?? 0;
      state.sessionNet += hero.stack - start;
    }
  }
  state.result = {
    pots: [{ amount: pot, winnerIds: [winner.id], handName: null }],
    shown: [],
    uncontested: winner.id,
  };
  log(state, winner, "win", `${winner.name} wins ${pot} uncontested`, pot);
  for (const p of state.players) {
    p.committed = 0;
    p.betStreet = 0;
  }
  state.phase = "showdown";
  state.actorId = null;
  return state;
}

export function computePots(players: Player[]): Pot[] {
  const contrib = players.filter((p) => p.committed > 0);
  if (contrib.length === 0) return [];
  const levels = [...new Set(contrib.map((p) => p.committed))].sort((a, b) => a - b);
  const pots: Pot[] = [];
  let prev = 0;
  for (const level of levels) {
    const layer = contrib.filter((p) => p.committed >= level);
    const amount = (level - prev) * layer.length;
    const eligible = layer.filter((p) => !p.folded && !p.busted).map((p) => p.id);
    if (amount > 0) pots.push({ amount, eligible });
    prev = level;
  }
  return pots;
}

function goShowdown(state: GameState): GameState {
  returnUncalled(state);
  const live = state.players.filter(inHand);
  if (live.length <= 1) return finishUncontested(state);
  while (state.board.length < 5) {
    const burn = state.deck.pop();
    if (burn) state.burns.push(burn);
    const c = state.deck.pop();
    if (c) state.board.push(c);
  }

  const shown: ShowdownResult["shown"] = [];
  for (const p of live) {
    if (!p.hole || p.hole.length < 2) continue;
    const ev = evaluate([...p.hole, ...state.board]);
    p.showed = true;
    shown.push({
      playerId: p.id,
      hole: p.hole,
      handName: ev.name,
      rank: ev.rank,
      five: ev.five,
    });
    const st = state.playerStats[p.id] ?? emptyStats();
    st.showdowns += 1;
    st.wtsd += 1;
    state.playerStats[p.id] = st;
  }

  const pots = computePots(state.players);
  const awards: ShowdownResult["pots"] = [];
  for (const pot of pots) {
    const contenders = shown.filter((h) => pot.eligible.includes(h.playerId));
    if (contenders.length === 0) continue;
    const best = Math.max(...contenders.map((c) => c.rank));
    const winners = contenders.filter((c) => c.rank === best);
    const share = Math.floor(pot.amount / winners.length);
    let remainder = pot.amount - share * winners.length;
    const winnerPlayers = winners
      .map((w) => byId(state, w.playerId)!)
      .sort((a, b) => {
        const da = (a.seat - state.button + state.players.length) % state.players.length;
        const db = (b.seat - state.button + state.players.length) % state.players.length;
        return da - db;
      });
    for (const wp of winnerPlayers) {
      let add = share;
      if (remainder > 0) {
        add += 1;
        remainder -= 1;
      }
      wp.stack += add;
    }
    awards.push({
      amount: pot.amount,
      winnerIds: winners.map((w) => w.playerId),
      handName: winners[0]?.handName ?? null,
    });
    for (const w of winners) {
      const st = state.playerStats[w.playerId] ?? emptyStats();
      st.wins += 1;
      state.playerStats[w.playerId] = st;
    }
    const names = winners.map((w) => byId(state, w.playerId)?.name ?? w.playerId).join(" & ");
    log(
      state,
      null,
      "win",
      `${names} win${winners.length > 1 ? "" : "s"} ${pot.amount}${winners[0] ? ` with ${winners[0].handName}` : ""}`,
      pot.amount,
    );
  }

  const hero = byId(state, "hero");
  if (hero) {
    const start = state.lastStartStacks.hero ?? 0;
    state.sessionNet += hero.stack - start;
  }

  for (const p of state.players) {
    p.committed = 0;
    p.betStreet = 0;
  }
  state.result = { pots: awards, shown };
  state.phase = "showdown";
  state.actorId = null;
  return state;
}

export function concludeShowdown(state: GameState): GameState {
  const s = clone(state);
  for (const p of s.players) {
    if (p.stack <= 0) p.busted = true;
  }
  const hero = byId(s, "hero");
  const live = livePlayers(s);
  if (!hero || hero.busted) {
    s.phase = "busted";
    s.actorId = null;
    return s;
  }
  if (live.length <= 1) {
    s.phase = "winner";
    s.actorId = null;
    return s;
  }
  s.phase = "between";
  s.actorId = null;
  return s;
}

export function rebuyHero(state: GameState): GameState {
  const s = clone(state);
  const hero = byId(s, "hero");
  if (!hero) return s;
  hero.stack = s.config.buyInBb * s.config.bigBlind;
  hero.busted = false;
  hero.folded = false;
  hero.allIn = false;
  s.phase = "between";
  return startHand(s);
}

export function nextHand(state: GameState): GameState {
  if (state.phase !== "between") return state;
  return startHand(state);
}

export function heroDelta(state: GameState): number {
  const hero = byId(state, "hero");
  if (!hero) return 0;
  return hero.stack - (state.lastStartStacks.hero ?? hero.stack);
}

export function actorPlayer(state: GameState): Player | undefined {
  return state.actorId ? byId(state, state.actorId) : undefined;
}

export function streetLabel(street: Street): string {
  return street === "preflop" ? "Preflop" : street[0]!.toUpperCase() + street.slice(1);
}

export function describeHole(hole: Card[] | null): string {
  if (!hole || hole.length < 2) return "";
  return holeLabel(hole[0]!, hole[1]!);
}

export { bestHand, evaluate };
