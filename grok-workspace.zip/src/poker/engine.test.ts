import assert from "node:assert/strict";
import { test } from "node:test";
import { applyAction, beginActing, computePots, legalActions, sitDown, newLobby, potTotal } from "./engine.ts";
import type { Player } from "./types.ts";

test("sit down starts a dealing hand with hole cards", () => {
  const g = sitDown(newLobby({ seats: 6, difficulty: "pro" }, 42));
  assert.equal(g.phase, "dealing");
  const hero = g.players.find((p) => p.isHuman)!;
  assert.equal(hero.hole?.length, 2);
  assert.equal(g.players.length, 6);
  assert.ok(potTotal(g) >= g.config.smallBlind + g.config.bigBlind);
});

test("folding around awards uncontested pot", () => {
  let g = sitDown(newLobby({ seats: 2, difficulty: "pro" }, 7));
  g = beginActing(g);
  let guard = 0;
  while (g.phase === "acting" && g.actorId && g.actorId !== "hero" && guard++ < 12) {
    const legal = legalActions(g);
    g = applyAction(g, legal.canCheck ? { kind: "check" } : { kind: "fold" });
  }
  if (g.phase === "acting" && g.actorId === "hero") {
    g = applyAction(g, { kind: "fold" });
  }
  assert.ok(g.phase === "showdown" || g.phase === "acting" || g.phase === "runout" || g.phase === "dealing");
});

test("side pots split by committed levels", () => {
  const players: Player[] = [
    {
      id: "a",
      seat: 0,
      name: "A",
      isHuman: true,
      personalityId: null,
      stack: 0,
      hole: null,
      betStreet: 0,
      committed: 100,
      folded: false,
      allIn: true,
      busted: false,
      showed: false,
      vpipHand: true,
      pfrHand: false,
    },
    {
      id: "b",
      seat: 1,
      name: "B",
      isHuman: false,
      personalityId: "vesper",
      stack: 0,
      hole: null,
      betStreet: 0,
      committed: 300,
      folded: false,
      allIn: true,
      busted: false,
      showed: false,
      vpipHand: true,
      pfrHand: true,
    },
    {
      id: "c",
      seat: 2,
      name: "C",
      isHuman: false,
      personalityId: "juno",
      stack: 200,
      hole: null,
      betStreet: 0,
      committed: 300,
      folded: false,
      allIn: false,
      busted: false,
      showed: false,
      vpipHand: true,
      pfrHand: false,
    },
  ];
  const pots = computePots(players);
  assert.equal(pots[0]?.amount, 300);
  assert.deepEqual(pots[0]?.eligible, ["a", "b", "c"]);
  assert.equal(pots[1]?.amount, 400);
  assert.deepEqual(pots[1]?.eligible, ["b", "c"]);
});
