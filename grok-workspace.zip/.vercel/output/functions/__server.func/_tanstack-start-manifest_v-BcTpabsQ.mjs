//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BcTpabsQ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CFpGpmuS.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CFpGpmuS.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DvFafnpX.js"]
	}
} });
//#endregion
export { tsrStartManifest };
