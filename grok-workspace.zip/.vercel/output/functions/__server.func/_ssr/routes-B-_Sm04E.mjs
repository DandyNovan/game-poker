import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as BookOpen, i as Brain, n as ScrollText, r as Menu } from "../_libs/lucide-react.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-B-_Sm04E.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SUITS = [
	"s",
	"h",
	"d",
	"c"
];
var RANK_LABEL = {
	2: "2",
	3: "3",
	4: "4",
	5: "5",
	6: "6",
	7: "7",
	8: "8",
	9: "9",
	10: "10",
	11: "J",
	12: "Q",
	13: "K",
	14: "A"
};
var SUIT_GLYPH = {
	s: "♠",
	h: "♥",
	d: "♦",
	c: "♣"
};
function isRed(suit) {
	return suit === "h" || suit === "d";
}
function cardId(c) {
	return `${RANK_LABEL[c.rank]}${c.suit}`;
}
function fullDeck() {
	const deck = [];
	for (const suit of SUITS) for (let r = 2; r <= 14; r++) deck.push({
		rank: r,
		suit
	});
	return deck;
}
function mulberry32(seed) {
	let a = seed >>> 0;
	return () => {
		a = a + 1831565813 | 0;
		let t = Math.imul(a ^ a >>> 15, 1 | a);
		t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
/** Unbiased Fisher–Yates. */
function shuffle(items, rng) {
	const arr = items.slice();
	for (let i = arr.length - 1; i > 0; i--) {
		const j = Math.floor(rng() * (i + 1));
		const tmp = arr[i];
		arr[i] = arr[j];
		arr[j] = tmp;
	}
	return arr;
}
function sameCard(a, b) {
	return a.rank === b.rank && a.suit === b.suit;
}
function cardIn(list, c) {
	return list.some((x) => sameCard(x, c));
}
function removeCards(deck, used) {
	return deck.filter((c) => !cardIn(used, c));
}
function holeLabel(a, b) {
	const hi = a.rank >= b.rank ? a : b;
	const lo = a.rank >= b.rank ? b : a;
	if (hi.rank === lo.rank) return `${RANK_LABEL[hi.rank]}${RANK_LABEL[lo.rank]}`;
	const suited = hi.suit === lo.suit ? "s" : "o";
	return `${RANK_LABEL[hi.rank]}${RANK_LABEL[lo.rank]}${suited}`;
}
function formatChips(n) {
	const sign = n < 0 ? "-" : "";
	const v = Math.abs(Math.round(n));
	if (v >= 1e6) {
		const m = v / 1e6;
		return `${sign}${m >= 10 ? m.toFixed(1) : m.toFixed(2)}M`;
	}
	if (v >= 1e4) {
		const k = v / 1e3;
		return `${sign}${k >= 100 ? Math.round(k) : k.toFixed(1)}k`;
	}
	return `${sign}${v.toLocaleString("en-US")}`;
}
function formatBb(chips, bb) {
	if (bb <= 0) return formatChips(chips);
	const x = chips / bb;
	const abs = Math.abs(x);
	const body = abs >= 100 ? abs.toFixed(0) : abs >= 10 ? abs.toFixed(1) : abs.toFixed(2);
	return `${x < 0 ? "-" : ""}${body} BB`;
}
var CAT_ORDER = [
	"high-card",
	"pair",
	"two-pair",
	"trips",
	"straight",
	"flush",
	"full-house",
	"quads",
	"straight-flush"
];
function pack(category, kickers) {
	let v = CAT_ORDER.indexOf(category);
	const k = kickers.slice(0, 5);
	while (k.length < 5) k.push(0);
	for (const x of k) v = v << 4 | x & 15;
	return v;
}
function pickByRank(cards, rank, n) {
	return cards.filter((c) => c.rank === rank).slice(0, n);
}
function highestNot(cards, banned, n) {
	const rest = cards.filter((c) => !banned.includes(c.rank)).slice().sort((a, b) => b.rank - a.rank);
	const out = [];
	const seen = /* @__PURE__ */ new Set();
	for (const c of rest) {
		const id = `${c.rank}${c.suit}`;
		if (seen.has(id)) continue;
		seen.add(id);
		out.push(c);
		if (out.length >= n) break;
	}
	return out;
}
function uniqueSortedRanks(cards) {
	return [...new Set(cards.map((c) => c.rank))].sort((a, b) => b - a);
}
/** High card of a 5-card straight, or 0. Ace is 14 and also 1 (wheel). */
function straightHigh(ranks) {
	const set = new Set(ranks);
	if (set.has(14)) set.add(1);
	for (let h = 14; h >= 5; h--) if (set.has(h) && set.has(h - 1) && set.has(h - 2) && set.has(h - 3) && set.has(h - 4)) return h;
	return 0;
}
function straightCards(cards, high) {
	const want = high === 5 ? [
		5,
		4,
		3,
		2,
		14
	] : [
		high,
		high - 1,
		high - 2,
		high - 3,
		high - 4
	];
	const used = [];
	for (const r of want) {
		const c = cards.find((x) => x.rank === r && !used.some((u) => sameCard(u, x)));
		if (c) used.push(c);
	}
	return used;
}
function nameOf(category, kickers) {
	const r = (n) => RANK_LABEL[n] ?? String(n);
	switch (category) {
		case "straight-flush": return kickers[0] === 14 ? "Royal flush" : `Straight flush, ${r(kickers[0])} high`;
		case "quads": return `Four of a kind, ${r(kickers[0])}s`;
		case "full-house": return `Full house, ${r(kickers[0])}s full of ${r(kickers[1])}s`;
		case "flush": return `Flush, ${r(kickers[0])} high`;
		case "straight": return `Straight, ${r(kickers[0])} high`;
		case "trips": return `Three of a kind, ${r(kickers[0])}s`;
		case "two-pair": return `Two pair, ${r(kickers[0])}s and ${r(kickers[1])}s`;
		case "pair": return `Pair of ${r(kickers[0])}s`;
		default: return `${r(kickers[0])} high`;
	}
}
function evaluate(cards) {
	if (cards.length < 5 || cards.length > 7) throw new Error(`evaluate expects 5–7 cards, got ${cards.length}`);
	const sorted = cards.slice().sort((a, b) => b.rank - a.rank || a.suit.localeCompare(b.suit));
	const byRank = /* @__PURE__ */ new Map();
	const bySuit = /* @__PURE__ */ new Map();
	for (const c of sorted) {
		const rr = byRank.get(c.rank) ?? [];
		rr.push(c);
		byRank.set(c.rank, rr);
		const ss = bySuit.get(c.suit) ?? [];
		ss.push(c);
		bySuit.set(c.suit, ss);
	}
	const groups = [...byRank.entries()].sort((a, b) => b[1].length - a[1].length || b[0] - a[0]);
	let flushSuit = null;
	let flushCards = [];
	for (const [s, list] of bySuit) if (list.length >= 5 && list.length > flushCards.length) {
		flushSuit = s;
		flushCards = list.slice().sort((a, b) => b.rank - a.rank);
	}
	if (flushSuit) {
		const sfHigh = straightHigh(flushCards.map((c) => c.rank));
		if (sfHigh) {
			const five = straightCards(flushCards, sfHigh);
			const kickers = [sfHigh];
			return {
				rank: pack("straight-flush", kickers),
				category: "straight-flush",
				name: nameOf("straight-flush", kickers),
				five
			};
		}
	}
	const quads = groups.find((g) => g[1].length === 4);
	if (quads) {
		const kicker = highestNot(sorted, [quads[0]], 1);
		const five = [...quads[1], ...kicker];
		const kickers = [quads[0], kicker[0]?.rank ?? 0];
		return {
			rank: pack("quads", kickers),
			category: "quads",
			name: nameOf("quads", kickers),
			five
		};
	}
	const tripsList = groups.filter((g) => g[1].length >= 3);
	const pairList = groups.filter((g) => g[1].length >= 2 && g[1].length < 4);
	if (tripsList.length >= 1 && (pairList.length >= 1 || tripsList.length >= 2)) {
		const tripRank = tripsList[0][0];
		let pairRank;
		if (tripsList.length >= 2) pairRank = tripsList[1][0];
		else pairRank = pairList.filter((g) => g[0] !== tripRank).sort((a, b) => b[0] - a[0])[0][0];
		const five = [...pickByRank(sorted, tripRank, 3), ...pickByRank(sorted, pairRank, 2)];
		const kickers = [tripRank, pairRank];
		return {
			rank: pack("full-house", kickers),
			category: "full-house",
			name: nameOf("full-house", kickers),
			five
		};
	}
	if (flushCards.length >= 5) {
		const five = flushCards.slice(0, 5);
		const kickers = five.map((c) => c.rank);
		return {
			rank: pack("flush", kickers),
			category: "flush",
			name: nameOf("flush", kickers),
			five
		};
	}
	const sHigh = straightHigh(uniqueSortedRanks(sorted));
	if (sHigh) {
		const five = straightCards(sorted, sHigh);
		const kickers = [sHigh];
		return {
			rank: pack("straight", kickers),
			category: "straight",
			name: nameOf("straight", kickers),
			five
		};
	}
	if (tripsList.length >= 1) {
		const tripRank = tripsList[0][0];
		const kick = highestNot(sorted, [tripRank], 2);
		const five = [...pickByRank(sorted, tripRank, 3), ...kick];
		const kickers = [tripRank, ...kick.map((c) => c.rank)];
		return {
			rank: pack("trips", kickers),
			category: "trips",
			name: nameOf("trips", kickers),
			five
		};
	}
	const pairs = groups.filter((g) => g[1].length === 2).sort((a, b) => b[0] - a[0]);
	if (pairs.length >= 2) {
		const hi = pairs[0][0];
		const lo = pairs[1][0];
		const kick = highestNot(sorted, [hi, lo], 1);
		const five = [
			...pickByRank(sorted, hi, 2),
			...pickByRank(sorted, lo, 2),
			...kick
		];
		const kickers = [
			hi,
			lo,
			kick[0]?.rank ?? 0
		];
		return {
			rank: pack("two-pair", kickers),
			category: "two-pair",
			name: nameOf("two-pair", kickers),
			five
		};
	}
	if (pairs.length === 1) {
		const pr = pairs[0][0];
		const kick = highestNot(sorted, [pr], 3);
		const five = [...pickByRank(sorted, pr, 2), ...kick];
		const kickers = [pr, ...kick.map((c) => c.rank)];
		return {
			rank: pack("pair", kickers),
			category: "pair",
			name: nameOf("pair", kickers),
			five
		};
	}
	const five = sorted.slice(0, 5);
	const kickers = five.map((c) => c.rank);
	return {
		rank: pack("high-card", kickers),
		category: "high-card",
		name: nameOf("high-card", kickers),
		five
	};
}
function bestHand(hole, board) {
	const cards = [...hole, ...board];
	if (cards.length < 5) return null;
	return evaluate(cards);
}
function categoryIndex(c) {
	return CAT_ORDER.indexOf(c);
}
function chenScore(a, b) {
	const scoreHigh = (r) => {
		if (r === 14) return 10;
		if (r === 13) return 8;
		if (r === 12) return 7;
		if (r === 11) return 6;
		if (r === 10) return 5;
		return r / 2;
	};
	const hi = Math.max(a.rank, b.rank);
	const lo = Math.min(a.rank, b.rank);
	let s = scoreHigh(hi);
	if (a.rank === b.rank) s = Math.max(s * 2, 5);
	else {
		if (a.suit === b.suit) s += 2;
		const gap = hi - lo - 1;
		if (gap === 0) s += 1;
		else if (gap === 1) s -= 1;
		else if (gap === 2) s -= 2;
		else if (gap === 3) s -= 4;
		else s -= 5;
		if (gap === 0 && hi < 12) s += 1;
		if (hi < 14 && lo >= 10) s += 1;
	}
	return Math.max(0, Math.ceil(s));
}
function analyzeBoard(board) {
	if (board.length < 3) return {
		paired: false,
		trips: false,
		monotone: false,
		twoTone: false,
		wet: false,
		connected: false,
		broadwayHeavy: false,
		dry: true,
		flushPossible: false,
		straightPossible: false
	};
	const suits = /* @__PURE__ */ new Map();
	const ranks = /* @__PURE__ */ new Map();
	for (const c of board) {
		suits.set(c.suit, (suits.get(c.suit) ?? 0) + 1);
		ranks.set(c.rank, (ranks.get(c.rank) ?? 0) + 1);
	}
	const suitCounts = [...suits.values()].sort((a, b) => b - a);
	const rankCounts = [...ranks.values()].sort((a, b) => b - a);
	const unique = [...ranks.keys()].sort((a, b) => a - b);
	const paired = (rankCounts[0] ?? 0) >= 2;
	const trips = (rankCounts[0] ?? 0) >= 3;
	const monotone = (suitCounts[0] ?? 0) >= 3 && board.length === 3 ? (suitCounts[0] ?? 0) === 3 : (suitCounts[0] ?? 0) >= 4;
	const twoTone = (suitCounts[0] ?? 0) >= 2 && (suitCounts[1] ?? 0) >= 2;
	const flushPossible = (suitCounts[0] ?? 0) >= 3;
	let connected = false;
	for (let i = 0; i < unique.length; i++) for (let j = i + 1; j < unique.length; j++) if (unique[j] - unique[i] <= 4) connected = true;
	const wheelish = unique.includes(14) && unique.some((r) => r <= 5);
	const straightPossible = connected || wheelish;
	const broadwayHeavy = board.filter((c) => c.rank >= 10).length >= 2;
	const wet = flushPossible && straightPossible;
	const dry = !paired && (suitCounts[0] ?? 0) <= 2 && !connected;
	return {
		paired,
		trips,
		monotone,
		twoTone,
		wet,
		connected,
		broadwayHeavy,
		dry,
		flushPossible,
		straightPossible
	};
}
function drawInfo(hole, board, dead = []) {
	const known = [
		...hole,
		...board,
		...dead
	];
	const made = board.length >= 3 ? evaluate([...hole, ...board]) : null;
	const madeIdx = made ? categoryIndex(made.category) : -1;
	const remaining = [];
	for (const suit of [
		"s",
		"h",
		"d",
		"c"
	]) for (let r = 2; r <= 14; r++) {
		const c = {
			rank: r,
			suit
		};
		if (!known.some((k) => sameCard(k, c))) remaining.push(c);
	}
	const suitCounts = /* @__PURE__ */ new Map();
	for (const c of [...hole, ...board]) suitCounts.set(c.suit, (suitCounts.get(c.suit) ?? 0) + 1);
	let flushDraw = false;
	let flushOuts = 0;
	for (const [s, n] of suitCounts) if (n === 4) {
		flushDraw = true;
		flushOuts = remaining.filter((c) => c.suit === s).length;
	}
	const ranks = [...new Set([...hole, ...board].map((c) => c.rank))];
	const sNow = board.length >= 3 ? straightHigh(ranks) : 0;
	let oesd = false;
	let gutshot = false;
	if (!sNow && board.length >= 3) {
		let eight = 0;
		let four = 0;
		for (const c of remaining) if (straightHigh([...ranks, c.rank])) {
			if (remaining.filter((x) => x.rank === c.rank).length >= 4) eight += 1;
			else four += 1;
		}
		const uniqueImprovers = new Set(remaining.filter((c) => straightHigh([...ranks, c.rank])).map((c) => c.rank)).size;
		if (uniqueImprovers >= 2) oesd = true;
		else if (uniqueImprovers === 1) gutshot = true;
	}
	const boardMax = board.reduce((m, c) => Math.max(m, c.rank), 0);
	const overcards = hole.filter((c) => c.rank > boardMax && !board.some((b) => b.rank === c.rank)).length;
	const outCards = [];
	if (board.length >= 3) for (const c of remaining) {
		const next = evaluate([
			...hole,
			...board,
			c
		]);
		if (categoryIndex(next.category) > madeIdx) outCards.push(c);
		else if (made && next.rank > made.rank) outCards.push(c);
	}
	const outs = outCards.length;
	return {
		flushDraw,
		flushOuts,
		oesd,
		gutshot,
		overcards,
		outs,
		outCards,
		comboDraw: flushDraw && (oesd || gutshot)
	};
}
function madeBucket(hole, board) {
	if (board.length < 3) return "air";
	const ev = evaluate([...hole, ...board]);
	const boardEv = board.length >= 5 ? evaluate(board) : null;
	if (ev.category === "straight-flush" || ev.category === "quads") return "nuts";
	if (ev.category === "full-house" || ev.category === "flush" || ev.category === "straight") return boardEv && ev.rank >= boardEv.rank + 64 ? "nuts" : "strong";
	if (ev.category === "trips") return "strong";
	if (ev.category === "two-pair") return hole[0] && hole[1] && hole[0].rank === hole[1].rank ? "strong" : "top-pair";
	if (ev.category === "pair") {
		const pairRank = ev.five[0].rank;
		const boardRanks = board.map((c) => c.rank).sort((a, b) => b - a);
		const top = boardRanks[0] ?? 0;
		const second = boardRanks[1] ?? 0;
		const pocket = hole[0] && hole[1] && hole[0].rank === hole[1].rank ? hole[0].rank : 0;
		if (pocket && pocket > top) return "strong";
		if (pairRank === top) return "top-pair";
		if (pairRank === second || pocket && pocket >= second) return "middle-pair";
		return "weak-pair";
	}
	if (Math.max(hole[0]?.rank ?? 0, hole[1]?.rank ?? 0) === 14) return "ace-high";
	return "air";
}
var BUCKET_STRENGTH = {
	nuts: .99,
	strong: .84,
	"top-pair": .66,
	"middle-pair": .48,
	"weak-pair": .34,
	"ace-high": .22,
	air: .08
};
var PERSONALITIES = [
	{
		id: "vesper",
		name: "Vesper",
		tagline: "Tight-aggressive, range-aware",
		loose: .22,
		aggression: .78,
		bluff: .26,
		sticky: .32,
		positional: .9,
		polar: .7,
		talk: .12,
		tone: "bone"
	},
	{
		id: "raka",
		name: "Raka",
		tagline: "Trappy mid-stakes reg",
		loose: .26,
		aggression: .52,
		bluff: .18,
		sticky: .48,
		positional: .7,
		polar: .35,
		talk: .28,
		tone: "pine"
	},
	{
		id: "juno",
		name: "Juno",
		tagline: "High-volume pressure",
		loose: .42,
		aggression: .88,
		bluff: .46,
		sticky: .4,
		positional: .55,
		polar: .8,
		talk: .55,
		tone: "clay"
	},
	{
		id: "nadir",
		name: "Nadir",
		tagline: "Nit. Waits for premiums",
		loose: .12,
		aggression: .62,
		bluff: .08,
		sticky: .18,
		positional: .85,
		polar: .45,
		talk: .08,
		tone: "ink"
	},
	{
		id: "dimas",
		name: "Dimas",
		tagline: "LAG, isolation specialist",
		loose: .36,
		aggression: .74,
		bluff: .34,
		sticky: .38,
		positional: .8,
		polar: .6,
		talk: .4,
		tone: "mist"
	}
];
function difficultyTune(p, d) {
	if (d === "pro") return {
		...p,
		loose: p.loose * .92,
		aggression: Math.min(.92, p.aggression + .06),
		bluff: p.bluff * .95 + .04,
		sticky: p.sticky * .85,
		positional: Math.min(1, p.positional + .08)
	};
	if (d === "casual") return {
		...p,
		loose: Math.min(.55, p.loose + .12),
		aggression: p.aggression * .82,
		bluff: p.bluff * .7,
		sticky: Math.min(.7, p.sticky + .18),
		positional: p.positional * .7
	};
	return p;
}
function pickRoster(seats) {
	const order = [
		"vesper",
		"dimas",
		"raka",
		"juno",
		"nadir"
	];
	const n = Math.max(0, seats - 1);
	return order.slice(0, n).map((id) => PERSONALITIES.find((p) => p.id === id)).filter(Boolean);
}
var LINES = {
	fold: {
		low: ["Fold.", "Out."],
		mid: ["Not this one.", "I muck."],
		high: [
			"Nah.",
			"Too thin.",
			"You can have it."
		]
	},
	check: {
		low: ["Check."],
		mid: ["Check.", "Seeing a card."],
		high: ["Check it down?", "I'll peek."]
	},
	call: {
		low: ["Call."],
		mid: ["Call.", "I'm in."],
		high: ["Call. Let's see it.", "Alright, call."]
	},
	raise: {
		low: ["Raise."],
		mid: ["Raising.", "I make it more."],
		high: ["Let's play a pot.", "Pressure."]
	},
	allin: {
		low: ["All-in."],
		mid: ["I'm all-in."],
		high: ["All of it.", "Shove."]
	}
};
var emptyStats = () => ({
	hands: 0,
	vpip: 0,
	pfr: 0,
	threeBet: 0,
	aggro: 0,
	calls: 0,
	folds: 0,
	showdowns: 0,
	wtsd: 0,
	wins: 0
});
function clone(s) {
	return structuredClone(s);
}
function rngFrom(state) {
	const rng = mulberry32(state.rngSeed || 1);
	rng();
	rng();
	return rng;
}
function livePlayers(state) {
	return state.players.filter((p) => !p.busted);
}
function inHand(p) {
	return !p.busted && !p.folded;
}
function canAct(p) {
	return inHand(p) && !p.allIn && p.stack > 0;
}
function byId(state, id) {
	return state.players.find((p) => p.id === id);
}
function nextLiveSeat(state, from, step = 1) {
	const n = state.players.length;
	for (let i = 1; i <= n; i++) {
		const seat = (from + i * step + n * 8) % n;
		const p = state.players[seat];
		if (p && !p.busted) return seat;
	}
	return from;
}
function positionName(state, seat) {
	const n = livePlayers(state).length;
	if (n < 2) return "";
	const button = state.button;
	if (n === 2) return seat === button ? "BTN / SB" : "BB";
	const sb = nextLiveSeat(state, button);
	const bb = nextLiveSeat(state, sb);
	if (seat === button) return "BTN";
	if (seat === sb) return "SB";
	if (seat === bb) return "BB";
	const names = n === 6 ? [
		"UTG",
		"HJ",
		"CO"
	] : n === 4 ? ["UTG", "CO"] : ["UTG"];
	let s = nextLiveSeat(state, bb);
	let i = 0;
	while (s !== button && i < 8) {
		if (s === seat) return names[Math.min(i, names.length - 1)] ?? "MP";
		s = nextLiveSeat(state, s);
		i += 1;
	}
	return "MP";
}
function firstPreflopSeat(state) {
	if (livePlayers(state).length === 2) return state.button;
	return nextLiveSeat(state, nextLiveSeat(state, nextLiveSeat(state, state.button)));
}
function firstPostflopSeat(state) {
	if (livePlayers(state).length === 2) return nextLiveSeat(state, state.button);
	const sb = nextLiveSeat(state, state.button);
	let s = sb;
	for (let i = 0; i < state.players.length; i++) {
		const p = state.players[s];
		if (inHand(p) && !p.allIn) return s;
		s = nextLiveSeat(state, s);
	}
	return sb;
}
function potTotal(state) {
	return state.players.reduce((s, p) => s + p.committed, 0);
}
function log(state, p, kind, text, amount) {
	state.log.push({
		handId: state.handId,
		street: state.street,
		playerId: p?.id ?? "",
		name: p?.name ?? "Table",
		kind,
		amount,
		text
	});
	if (state.log.length > 240) state.log.splice(0, state.log.length - 240);
}
function commit(p, toStreetTotal) {
	const need = Math.max(0, toStreetTotal - p.betStreet);
	const put = Math.min(need, p.stack);
	p.stack -= put;
	p.betStreet += put;
	p.committed += put;
	if (p.stack === 0) p.allIn = true;
	return put;
}
function take(p, amount) {
	const put = Math.min(amount, p.stack);
	p.stack -= put;
	p.betStreet += put;
	p.committed += put;
	if (p.stack === 0) p.allIn = true;
	return put;
}
function defaultConfig(partial) {
	return {
		seats: 6,
		smallBlind: 50,
		bigBlind: 100,
		buyInBb: 100,
		difficulty: "pro",
		speed: "normal",
		playerName: "You",
		autoMuck: true,
		...partial
	};
}
function newLobby(config, seed) {
	const cfg = defaultConfig(config);
	return {
		config: cfg,
		phase: "lobby",
		handId: 0,
		street: "preflop",
		button: 0,
		deck: [],
		board: [],
		burns: [],
		players: [],
		currentBet: 0,
		lastFullRaise: cfg.bigBlind,
		toAct: [],
		actorId: null,
		lastAggressorId: null,
		log: [],
		result: null,
		rngSeed: seed ?? (Math.floor(Math.random() * 4294967295) || 1),
		sessionNet: 0,
		sessionHands: 0,
		playerStats: {},
		lastStartStacks: {},
		preflopRaises: 0,
		streetAggressions: 0,
		handContested: false
	};
}
function sitDown(state) {
	const s = clone(state);
	const cfg = s.config;
	const buy = cfg.buyInBb * cfg.bigBlind;
	const roster = pickRoster(cfg.seats);
	const players = [];
	players.push({
		id: "hero",
		seat: 0,
		name: cfg.playerName.trim() || "You",
		isHuman: true,
		personalityId: null,
		stack: buy,
		hole: null,
		betStreet: 0,
		committed: 0,
		folded: false,
		allIn: false,
		busted: false,
		showed: false,
		vpipHand: false,
		pfrHand: false
	});
	for (let i = 0; i < cfg.seats - 1; i++) {
		const per = roster[i];
		players.push({
			id: per.id,
			seat: i + 1,
			name: per.name,
			isHuman: false,
			personalityId: per.id,
			stack: buy,
			hole: null,
			betStreet: 0,
			committed: 0,
			folded: false,
			allIn: false,
			busted: false,
			showed: false,
			vpipHand: false,
			pfrHand: false
		});
	}
	s.players = players;
	s.playerStats = Object.fromEntries(players.map((p) => [p.id, emptyStats()]));
	s.button = Math.max(0, cfg.seats - 2);
	s.phase = "between";
	s.log = [];
	log(s, null, "deal", `Sat ${cfg.seats}-max · ${cfg.smallBlind}/${cfg.bigBlind} · ${cfg.difficulty}`);
	return startHand(s);
}
function resetPlayerForHand(p) {
	p.hole = null;
	p.betStreet = 0;
	p.committed = 0;
	p.folded = p.busted;
	p.allIn = false;
	p.showed = false;
	p.vpipHand = false;
	p.pfrHand = false;
	if (p.stack <= 0) {
		p.busted = true;
		p.folded = true;
	}
}
function startHand(state) {
	const s = clone(state);
	for (const p of s.players) {
		if (p.stack <= 0) p.busted = true;
		resetPlayerForHand(p);
	}
	const live = livePlayers(s);
	const hero = byId(s, "hero");
	if (!hero || hero.busted) {
		s.phase = "busted";
		s.actorId = null;
		return s;
	}
	if (live.length === 1) {
		s.phase = "winner";
		s.actorId = null;
		return s;
	}
	if (live.length < 2) {
		s.phase = "winner";
		return s;
	}
	s.handId += 1;
	s.sessionHands += 1;
	s.street = "preflop";
	s.board = [];
	s.burns = [];
	s.result = null;
	s.preflopRaises = 0;
	s.streetAggressions = 0;
	s.handContested = false;
	s.lastAggressorId = null;
	s.lastStartStacks = Object.fromEntries(s.players.map((p) => [p.id, p.stack]));
	for (const p of live) {
		const st = s.playerStats[p.id] ?? emptyStats();
		st.hands += 1;
		s.playerStats[p.id] = st;
	}
	s.button = nextLiveSeat(s, s.button);
	s.rngSeed = Math.imul(s.rngSeed || 1, 1664525) + 1013904223 >>> 0 || 1;
	const rng = rngFrom(s);
	s.deck = shuffle(fullDeck(), rng);
	const sbSeat = live.length === 2 ? s.button : nextLiveSeat(s, s.button);
	const bbSeat = live.length === 2 ? nextLiveSeat(s, s.button) : nextLiveSeat(s, sbSeat);
	const sb = s.players[sbSeat];
	const bb = s.players[bbSeat];
	const sbPut = take(sb, s.config.smallBlind);
	const bbPut = take(bb, s.config.bigBlind);
	log(s, sb, "blind", `${sb.name} posts SB ${sbPut}`, sbPut);
	log(s, bb, "blind", `${bb.name} posts BB ${bbPut}`, bbPut);
	let seat = sbSeat;
	for (let round = 0; round < 2; round++) for (let i = 0; i < live.length; i++) {
		const p = s.players[seat];
		if (!p.busted) {
			const c = s.deck.pop();
			if (c) p.hole = p.hole ? [...p.hole, c] : [c];
		}
		seat = nextLiveSeat(s, seat);
	}
	s.currentBet = Math.max(sb.betStreet, bb.betStreet);
	s.lastFullRaise = s.config.bigBlind;
	s.toAct = buildToAct(s, firstPreflopSeat(s));
	s.phase = "dealing";
	s.actorId = s.toAct[0] ?? null;
	log(s, null, "deal", `Hand #${s.handId} · button ${s.players[s.button]?.name ?? ""}`);
	return s;
}
function buildToAct(state, firstSeat) {
	const ids = [];
	let seat = firstSeat;
	for (let i = 0; i < state.players.length; i++) {
		const p = state.players[seat];
		if (canAct(p)) ids.push(p.id);
		seat = (seat + 1) % state.players.length;
	}
	return ids;
}
function beginActing(state) {
	const s = clone(state);
	if (s.phase !== "dealing" && s.phase !== "runout") return s;
	if (bettingClosed(s)) return continueAfterBetting(s);
	s.phase = "acting";
	s.actorId = s.toAct[0] ?? null;
	return s;
}
function bettingClosed(state) {
	const live = state.players.filter(inHand);
	if (live.length <= 1) return true;
	const actors = live.filter(canAct);
	if (actors.length === 0) return true;
	if (state.toAct.length === 0) return actors.filter((p) => p.betStreet < state.currentBet).length === 0;
	return false;
}
function legalActions(state, playerId) {
	const id = playerId ?? state.actorId;
	const empty = {
		canFold: false,
		canCheck: false,
		canCall: false,
		callAmount: 0,
		canBet: false,
		canRaise: false,
		minBet: 0,
		minRaiseTo: 0,
		maxTo: 0,
		canAllIn: false,
		allInAmount: 0
	};
	if (state.phase !== "acting" || !id) return empty;
	const p = byId(state, id);
	if (!p || !canAct(p) || state.toAct[0] !== id) return empty;
	const toCall = Math.max(0, state.currentBet - p.betStreet);
	const maxTo = p.betStreet + p.stack;
	const minBet = state.config.bigBlind;
	const minRaiseTo = state.currentBet + state.lastFullRaise;
	const canCheck = toCall === 0;
	const canCall = toCall > 0 && p.stack > 0;
	const canBet = toCall === 0 && p.stack > minBet;
	toCall > 0 && state.currentBet;
	const raiseOk = toCall > 0 && p.stack > toCall && maxTo > state.currentBet;
	return {
		canFold: true,
		canCheck,
		canCall: canCall && toCall < p.stack,
		callAmount: Math.min(toCall, p.stack),
		canBet,
		canRaise: raiseOk && maxTo >= minRaiseTo,
		minBet: Math.min(minBet, p.stack),
		minRaiseTo: Math.min(minRaiseTo, maxTo),
		maxTo,
		canAllIn: p.stack > 0,
		allInAmount: p.stack
	};
}
function trackVoluntarily(state, p, kind, aggressive) {
	const st = state.playerStats[p.id] ?? emptyStats();
	if (kind === "fold") st.folds += 1;
	if (kind === "call") st.calls += 1;
	if (aggressive) st.aggro += 1;
	if (state.street === "preflop") {
		if (kind !== "fold" && kind !== "check") {
			if (!p.vpipHand) {
				st.vpip += 1;
				p.vpipHand = true;
			}
		}
		if (aggressive) {
			if (!p.pfrHand) {
				st.pfr += 1;
				p.pfrHand = true;
			}
			if (state.preflopRaises >= 1) st.threeBet += 1;
		}
	}
	state.playerStats[p.id] = st;
}
function applyAction(state, action) {
	const s = clone(state);
	if (s.phase !== "acting" || !s.actorId) return s;
	const p = byId(s, s.actorId);
	if (!p || !canAct(p)) return s;
	const legal = legalActions(s, p.id);
	const kind = action.kind;
	if (kind === "fold") {
		if (!legal.canFold) return s;
		p.folded = true;
		trackVoluntarily(s, p, "fold", false);
		log(s, p, "fold", `${p.name} folds`);
		s.toAct = s.toAct.filter((id) => id !== p.id);
	} else if (kind === "check") {
		if (!legal.canCheck) return s;
		log(s, p, "check", `${p.name} checks`);
		s.toAct = s.toAct.filter((id) => id !== p.id);
	} else if (kind === "call") {
		if (!legal.canCall && !(legal.canAllIn && legal.callAmount >= p.stack)) return s;
		const put = commit(p, s.currentBet);
		trackVoluntarily(s, p, p.allIn ? "allin" : "call", false);
		log(s, p, p.allIn ? "allin" : "call", p.allIn ? `${p.name} calls all-in ${put}` : `${p.name} calls ${put}`, put);
		s.toAct = s.toAct.filter((id) => id !== p.id);
	} else if (kind === "bet") {
		if (!legal.canBet && !legal.canAllIn) return s;
		const put = commit(p, Math.max(legal.minBet, Math.min(action.amount ?? legal.minBet, legal.maxTo)));
		const isFull = p.betStreet >= s.config.bigBlind;
		s.currentBet = p.betStreet;
		if (isFull) s.lastFullRaise = p.betStreet;
		s.lastAggressorId = p.id;
		s.streetAggressions += 1;
		trackVoluntarily(s, p, p.allIn ? "allin" : "bet", true);
		if (s.street === "preflop") s.preflopRaises += 1;
		log(s, p, p.allIn ? "allin" : "bet", p.allIn ? `${p.name} bets all-in ${put}` : `${p.name} bets ${put}`, put);
		reopen(s, p.id);
	} else if (kind === "raise") {
		if (!legal.canRaise && !legal.canAllIn) return s;
		const to = Math.max(legal.minRaiseTo, Math.min(action.amount ?? legal.minRaiseTo, legal.maxTo));
		const prev = s.currentBet;
		const put = commit(p, to);
		const inc = p.betStreet - prev;
		const full = inc >= s.lastFullRaise;
		s.currentBet = Math.max(s.currentBet, p.betStreet);
		if (full) s.lastFullRaise = inc;
		s.lastAggressorId = p.id;
		s.streetAggressions += 1;
		trackVoluntarily(s, p, p.allIn ? "allin" : "raise", true);
		if (s.street === "preflop") s.preflopRaises += 1;
		log(s, p, p.allIn ? "allin" : "raise", p.allIn ? `${p.name} shoves ${put}` : `${p.name} raises to ${p.betStreet}`, put);
		if (full || p.betStreet > prev) reopen(s, p.id, full);
		else s.toAct = s.toAct.filter((id) => id !== p.id);
	} else if (kind === "allin") {
		const prev = s.currentBet;
		const put = take(p, p.stack);
		const newBet = p.betStreet;
		const inc = newBet - prev;
		s.currentBet = Math.max(s.currentBet, newBet);
		const fromZero = prev === 0;
		const full = fromZero ? newBet >= s.config.bigBlind : inc >= s.lastFullRaise;
		if (full) s.lastFullRaise = fromZero ? newBet : inc;
		if (newBet > prev) s.lastAggressorId = p.id;
		if (newBet > prev) s.streetAggressions += 1;
		trackVoluntarily(s, p, "allin", newBet > prev);
		if (s.street === "preflop" && newBet > prev) s.preflopRaises += 1;
		log(s, p, "allin", `${p.name} is all-in ${put}`, put);
		if (newBet > prev && full) reopen(s, p.id, true);
		else s.toAct = s.toAct.filter((id) => id !== p.id);
	}
	s.handContested = s.players.filter(inHand).length > 1;
	s.toAct = s.toAct.filter((id) => {
		const pl = byId(s, id);
		return pl && canAct(pl);
	});
	if (s.players.filter(inHand).length <= 1) return finishUncontested(s);
	if (bettingClosed(s)) return continueAfterBetting(s);
	s.actorId = s.toAct[0] ?? null;
	s.phase = "acting";
	return s;
}
function reopen(state, actorId, full = true) {
	if (!full) {
		state.toAct = state.toAct.filter((id) => id !== actorId);
		return;
	}
	const ids = [];
	const actor = byId(state, actorId);
	if (!actor) return;
	let seat = (actor.seat + 1) % state.players.length;
	for (let i = 0; i < state.players.length; i++) {
		const p = state.players[seat];
		if (p.id !== actorId && canAct(p)) ids.push(p.id);
		seat = (seat + 1) % state.players.length;
	}
	state.toAct = ids;
}
function returnUncalled(state) {
	const live = state.players.filter((p) => p.committed > 0);
	if (live.length === 0) return;
	const max = Math.max(...live.map((p) => p.committed));
	const second = Math.max(0, ...live.filter((p) => p.committed < max).map((p) => p.committed));
	const leaders = live.filter((p) => p.committed === max);
	if (leaders.length !== 1) return;
	const extra = max - Math.max(second, ...live.filter((p) => p.id !== leaders[0].id).map((p) => p.committed));
	if (extra > 0) {
		const p = leaders[0];
		p.committed -= extra;
		p.betStreet = Math.max(0, p.betStreet - extra);
		p.stack += extra;
		if (p.stack > 0) p.allIn = false;
		log(state, p, "return", `Uncalled ${extra} returned to ${p.name}`, extra);
	}
}
function continueAfterBetting(state) {
	const live = state.players.filter(inHand);
	if (live.length <= 1) return finishUncontested(state);
	const actors = live.filter(canAct);
	const stillToMatch = actors.filter((p) => p.betStreet < state.currentBet);
	if (stillToMatch.length > 0) {
		state.toAct = stillToMatch.map((p) => p.id);
		state.actorId = state.toAct[0] ?? null;
		state.phase = "acting";
		return state;
	}
	for (const p of state.players) p.betStreet = 0;
	if (live.length === 1) return finishUncontested(state);
	const allLocked = actors.length <= 1;
	if (state.street === "river" || allLocked && state.board.length === 5) return goShowdown(state);
	if (allLocked) {
		state.phase = "runout";
		state.actorId = null;
		return state;
	}
	state.phase = "runout";
	state.actorId = null;
	return state;
}
function dealNextStreet(state) {
	const s = clone(state);
	if (s.phase !== "runout" && s.phase !== "dealing") return s;
	if (s.players.filter(inHand).length <= 1) return finishUncontested(s);
	const burn = s.deck.pop();
	if (burn) s.burns.push(burn);
	if (s.street === "preflop") {
		const c1 = s.deck.pop();
		const c2 = s.deck.pop();
		const c3 = s.deck.pop();
		if (c1 && c2 && c3) s.board.push(c1, c2, c3);
		s.street = "flop";
		log(s, null, "deal", `Flop ${s.board.map(cardId).join(" ")}`);
	} else if (s.street === "flop") {
		const c = s.deck.pop();
		if (c) s.board.push(c);
		s.street = "turn";
		log(s, null, "deal", `Turn ${cardId(s.board[3])}`);
	} else if (s.street === "turn") {
		const c = s.deck.pop();
		if (c) s.board.push(c);
		s.street = "river";
		log(s, null, "deal", `River ${cardId(s.board[4])}`);
	} else return goShowdown(s);
	s.currentBet = 0;
	s.lastFullRaise = s.config.bigBlind;
	s.lastAggressorId = null;
	s.streetAggressions = 0;
	for (const p of s.players) p.betStreet = 0;
	if (s.players.filter(inHand).filter(canAct).length <= 1) {
		if (s.street === "river" || s.board.length === 5) return goShowdown(s);
		s.phase = "runout";
		s.actorId = null;
		return s;
	}
	s.toAct = buildToAct(s, firstPostflopSeat(s));
	s.actorId = s.toAct[0] ?? null;
	s.phase = "acting";
	return s;
}
function finishUncontested(state) {
	returnUncalled(state);
	const winner = state.players.find(inHand);
	if (!winner) {
		state.phase = "between";
		return state;
	}
	const pot = potTotal(state);
	winner.stack += pot;
	const st = state.playerStats[winner.id] ?? emptyStats();
	st.wins += 1;
	state.playerStats[winner.id] = st;
	if (winner.id === "hero") {
		const start = state.lastStartStacks[winner.id] ?? 0;
		state.sessionNet += winner.stack - start;
	} else {
		const hero = byId(state, "hero");
		if (hero) {
			const start = state.lastStartStacks.hero ?? 0;
			state.sessionNet += hero.stack - start;
		}
	}
	state.result = {
		pots: [{
			amount: pot,
			winnerIds: [winner.id],
			handName: null
		}],
		shown: [],
		uncontested: winner.id
	};
	log(state, winner, "win", `${winner.name} wins ${pot} uncontested`, pot);
	for (const p of state.players) {
		p.committed = 0;
		p.betStreet = 0;
	}
	state.phase = "showdown";
	state.actorId = null;
	return state;
}
function computePots(players) {
	const contrib = players.filter((p) => p.committed > 0);
	if (contrib.length === 0) return [];
	const levels = [...new Set(contrib.map((p) => p.committed))].sort((a, b) => a - b);
	const pots = [];
	let prev = 0;
	for (const level of levels) {
		const layer = contrib.filter((p) => p.committed >= level);
		const amount = (level - prev) * layer.length;
		const eligible = layer.filter((p) => !p.folded && !p.busted).map((p) => p.id);
		if (amount > 0) pots.push({
			amount,
			eligible
		});
		prev = level;
	}
	return pots;
}
function goShowdown(state) {
	returnUncalled(state);
	const live = state.players.filter(inHand);
	if (live.length <= 1) return finishUncontested(state);
	while (state.board.length < 5) {
		const burn = state.deck.pop();
		if (burn) state.burns.push(burn);
		const c = state.deck.pop();
		if (c) state.board.push(c);
	}
	const shown = [];
	for (const p of live) {
		if (!p.hole || p.hole.length < 2) continue;
		const ev = evaluate([...p.hole, ...state.board]);
		p.showed = true;
		shown.push({
			playerId: p.id,
			hole: p.hole,
			handName: ev.name,
			rank: ev.rank,
			five: ev.five
		});
		const st = state.playerStats[p.id] ?? emptyStats();
		st.showdowns += 1;
		st.wtsd += 1;
		state.playerStats[p.id] = st;
	}
	const pots = computePots(state.players);
	const awards = [];
	for (const pot of pots) {
		const contenders = shown.filter((h) => pot.eligible.includes(h.playerId));
		if (contenders.length === 0) continue;
		const best = Math.max(...contenders.map((c) => c.rank));
		const winners = contenders.filter((c) => c.rank === best);
		const share = Math.floor(pot.amount / winners.length);
		let remainder = pot.amount - share * winners.length;
		const winnerPlayers = winners.map((w) => byId(state, w.playerId)).sort((a, b) => {
			return (a.seat - state.button + state.players.length) % state.players.length - (b.seat - state.button + state.players.length) % state.players.length;
		});
		for (const wp of winnerPlayers) {
			let add = share;
			if (remainder > 0) {
				add += 1;
				remainder -= 1;
			}
			wp.stack += add;
		}
		awards.push({
			amount: pot.amount,
			winnerIds: winners.map((w) => w.playerId),
			handName: winners[0]?.handName ?? null
		});
		for (const w of winners) {
			const st = state.playerStats[w.playerId] ?? emptyStats();
			st.wins += 1;
			state.playerStats[w.playerId] = st;
		}
		log(state, null, "win", `${winners.map((w) => byId(state, w.playerId)?.name ?? w.playerId).join(" & ")} win${winners.length > 1 ? "" : "s"} ${pot.amount}${winners[0] ? ` with ${winners[0].handName}` : ""}`, pot.amount);
	}
	const hero = byId(state, "hero");
	if (hero) {
		const start = state.lastStartStacks.hero ?? 0;
		state.sessionNet += hero.stack - start;
	}
	for (const p of state.players) {
		p.committed = 0;
		p.betStreet = 0;
	}
	state.result = {
		pots: awards,
		shown
	};
	state.phase = "showdown";
	state.actorId = null;
	return state;
}
function concludeShowdown(state) {
	const s = clone(state);
	for (const p of s.players) if (p.stack <= 0) p.busted = true;
	const hero = byId(s, "hero");
	const live = livePlayers(s);
	if (!hero || hero.busted) {
		s.phase = "busted";
		s.actorId = null;
		return s;
	}
	if (live.length <= 1) {
		s.phase = "winner";
		s.actorId = null;
		return s;
	}
	s.phase = "between";
	s.actorId = null;
	return s;
}
function rebuyHero(state) {
	const s = clone(state);
	const hero = byId(s, "hero");
	if (!hero) return s;
	hero.stack = s.config.buyInBb * s.config.bigBlind;
	hero.busted = false;
	hero.folded = false;
	hero.allIn = false;
	s.phase = "between";
	return startHand(s);
}
function nextHand(state) {
	if (state.phase !== "between") return state;
	return startHand(state);
}
function describeHole(hole) {
	if (!hole || hole.length < 2) return "";
	return holeLabel(hole[0], hole[1]);
}
/**
* Monte Carlo equity for a hero hand vs N unknown opponent hands.
* Ties split equally. Fast enough for live coach / Pro AI (~150 samples).
*/
function monteCarloEquity(hole, board, nOpp, samples, seed, extraDead = []) {
	const dead = [
		...hole,
		...board,
		...extraDead
	];
	const base = removeCards(fullDeck(), dead);
	const needBoard = Math.max(0, 5 - board.length);
	const rng = mulberry32(seed || 1);
	let win = 0;
	let tie = 0;
	let lose = 0;
	const oppCount = Math.max(1, nOpp);
	for (let s = 0; s < samples; s++) {
		const deck = shuffle(base, rng);
		let i = 0;
		const opps = [];
		let ok = true;
		for (let o = 0; o < oppCount; o++) {
			if (i + 1 >= deck.length) {
				ok = false;
				break;
			}
			opps.push([deck[i], deck[i + 1]]);
			i += 2;
		}
		if (!ok) continue;
		const runout = board.slice();
		for (let k = 0; k < needBoard; k++) {
			if (i >= deck.length) {
				ok = false;
				break;
			}
			runout.push(deck[i++]);
		}
		if (!ok || runout.length < 5) continue;
		const hero = evaluate([...hole, ...runout]).rank;
		let bestOpp = -1;
		let tied = 0;
		for (const oh of opps) {
			const r = evaluate([...oh, ...runout]).rank;
			if (r > bestOpp) {
				bestOpp = r;
				tied = 1;
			} else if (r === bestOpp) tied += 1;
		}
		if (hero > bestOpp) win += 1;
		else if (hero === bestOpp) tie += 1 / (tied + 1);
		else lose += 1;
	}
	const n = win + tie + lose;
	return {
		win,
		tie,
		lose,
		equity: n ? (win + tie) / n : .5,
		samples: n
	};
}
function potOdds(toCall, pot) {
	if (toCall <= 0) return 0;
	return toCall / (pot + toCall);
}
function spr(stack, pot) {
	if (pot <= 0) return 99;
	return stack / pot;
}
function roundTo(n, step) {
	if (step <= 0) return Math.round(n);
	return Math.max(step, Math.round(n / step) * step);
}
function pick(rng, a, b, pA) {
	return rng() < pA ? a : b;
}
function personalityOf(p) {
	return PERSONALITIES.find((x) => x.id === p.personalityId) ?? PERSONALITIES[0];
}
function rfiThreshold(pos) {
	if (pos.startsWith("UTG") || pos === "HJ") return 9;
	if (pos === "CO") return 7;
	if (pos === "BTN" || pos.startsWith("BTN")) return 5.5;
	if (pos === "SB") return 7;
	return 8;
}
function openSize(state, pos, stack, polar) {
	const bb = state.config.bigBlind;
	let x = 2.3;
	if (pos === "SB") x = 3.2;
	if (pos.startsWith("UTG")) x = 2.5;
	x += polar * .3;
	const limpers = state.players.filter((p) => !p.folded && !p.busted && p.betStreet === bb && p.id !== state.actorId).length;
	if (limpers) x += .8 * limpers;
	return Math.min(stack, roundTo(x * bb, state.config.smallBlind));
}
function betSize(state, me, polar, wet, street) {
	const pot = potTotal(state);
	const legal = legalActions(state, me.id);
	let frac = wet ? .72 : .42;
	if (street === "flop" && !wet) frac = .33;
	if (street === "turn") frac = wet ? .75 : .55;
	if (street === "river") frac = polar > .6 ? .95 : .66;
	const raw = pot * frac;
	const to = (state.currentBet === 0 ? 0 : me.betStreet) + raw;
	const stepped = roundTo(Math.max(legal.minBet, to === 0 ? legal.minBet : raw), state.config.smallBlind);
	if (state.currentBet === 0) return Math.min(legal.maxTo, Math.max(legal.minBet, stepped));
	const raiseTo = Math.max(legal.minRaiseTo, me.betStreet + stepped);
	return Math.min(legal.maxTo, raiseTo);
}
function shove(legal, me) {
	return {
		kind: "allin",
		amount: me.betStreet + me.stack
	};
}
function raiseTo(legal, to, me) {
	const capped = Math.min(legal.maxTo, Math.max(legal.minRaiseTo || legal.minBet, to));
	if (capped >= me.betStreet + me.stack) return shove(legal, me);
	if (legal.canBet && legal.callAmount === 0) return {
		kind: "bet",
		amount: capped
	};
	if (legal.canRaise) return {
		kind: "raise",
		amount: capped
	};
	if (legal.canAllIn) return shove(legal, me);
	if (legal.canCall) return {
		kind: "call",
		amount: legal.callAmount
	};
	if (legal.canCheck) return { kind: "check" };
	return { kind: "fold" };
}
function passive(legal) {
	if (legal.canCheck) return { kind: "check" };
	if (legal.canCall) return {
		kind: "call",
		amount: legal.callAmount
	};
	if (legal.canAllIn && legal.callAmount >= legal.allInAmount) return { kind: "allin" };
	return { kind: "fold" };
}
function chooseAction(state, seed = 1) {
	const me = state.players.find((p) => p.id === state.actorId);
	if (!me || !me.hole || me.hole.length < 2) return { kind: "fold" };
	const legal = legalActions(state, me.id);
	const rng = mulberry32((seed ^ state.handId * 997 ^ me.seat * 13) >>> 0 || 1);
	const pers = difficultyTune(personalityOf(me), state.config.difficulty);
	if (state.config.difficulty === "casual" && rng() < .1) return noisy(legal, rng);
	if (state.street === "preflop") return preflop(state, me, legal, pers, rng);
	return postflop(state, me, legal, pers, rng);
}
function noisy(legal, rng) {
	const options = [];
	if (legal.canCheck) options.push({ kind: "check" });
	if (legal.canCall) options.push({
		kind: "call",
		amount: legal.callAmount
	});
	if (legal.canBet) options.push({
		kind: "bet",
		amount: legal.minBet
	});
	if (legal.canRaise) options.push({
		kind: "raise",
		amount: legal.minRaiseTo
	});
	if (legal.canFold) options.push({ kind: "fold" });
	return options[Math.floor(rng() * options.length)] ?? { kind: "fold" };
}
function preflop(state, me, legal, pers, rng) {
	const hole = me.hole;
	const chen = chenScore(hole[0], hole[1]);
	const pos = positionName(state, me.seat);
	const bb = state.config.bigBlind;
	const stackBb = me.stack / bb;
	const raises = state.preflopRaises;
	const pot = potTotal(state);
	const toCall = legal.callAmount;
	const odds = potOdds(toCall, pot);
	const inBlinds = pos === "SB" || pos === "BB";
	if (stackBb <= 14 && (chen >= (raises === 0 ? 6 : 9) || chen >= 8 && stackBb <= 8)) {
		if (legal.canAllIn || legal.canRaise || legal.canBet) return shove(legal, me);
	}
	if (raises === 0) {
		const thresh = rfiThreshold(pos) * (1.18 - pers.loose);
		if (chen >= thresh) {
			const to = openSize(state, pos, me.betStreet + me.stack, pers.polar);
			return raiseTo(legal, me.betStreet + to, me);
		}
		if (pos === "BB" && legal.canCheck) return { kind: "check" };
		if (pos === "SB" && chen >= thresh - 2 && pers.loose > .3 && legal.canCall) return {
			kind: "call",
			amount: legal.callAmount
		};
		if (legal.canCheck) return { kind: "check" };
		return { kind: "fold" };
	}
	const threeThresh = 10.5 - pers.loose * 3;
	const fourThresh = 11.2 - pers.loose * 1.5;
	if (raises >= 2) {
		if (chen >= fourThresh) {
			if (stackBb <= 40 || chen >= 12) return shove(legal, me);
			return raiseTo(legal, Math.min(legal.maxTo, state.currentBet * 2.2), me);
		}
		if (chen >= 10 && toCall / pot < .55 && pers.sticky > .35 && legal.canCall) return {
			kind: "call",
			amount: legal.callAmount
		};
		if (legal.canCheck) return { kind: "check" };
		return { kind: "fold" };
	}
	const ip = pos === "BTN" || pos === "CO" || pos === "BB";
	if (chen >= threeThresh || chen >= threeThresh - 1.5 && pers.aggression > .7 && rng() < pers.bluff) return raiseTo(legal, roundTo(state.currentBet * (inBlinds ? 3.2 : 2.6), state.config.smallBlind), me);
	const defend = (ip ? 6 : 7.5) - pers.loose * 4;
	const priced = toCall <= bb * 4 || odds <= .32;
	if (chen >= defend && priced && legal.canCall) {
		if (rng() < pers.sticky + .25) return {
			kind: "call",
			amount: legal.callAmount
		};
	}
	if (pos === "BB" && chen >= defend - 1.5 && odds <= .36 && legal.canCall) return {
		kind: "call",
		amount: legal.callAmount
	};
	if (legal.canCheck) return { kind: "check" };
	return { kind: "fold" };
}
function postflop(state, me, legal, pers, rng) {
	const hole = me.hole;
	const board = state.board;
	const eq = monteCarloEquity(hole, board, Math.max(1, state.players.filter((p) => !p.folded && !p.busted && p.id !== me.id).length), state.config.difficulty === "pro" ? 160 : state.config.difficulty === "regular" ? 80 : 36, (state.rngSeed ^ me.seat * 7919) >>> 0 || 1).equity;
	const bucket = madeBucket(hole, board);
	const draws = drawInfo(hole, board);
	const texture = analyzeBoard(board);
	const pot = potTotal(state);
	const toCall = legal.callAmount;
	const odds = potOdds(toCall, pot);
	const stackSpr = spr(me.stack, Math.max(1, pot));
	const made = bestHand(hole, board);
	const strength = Math.max(eq, BUCKET_STRENGTH[bucket]);
	const facing = toCall > 0;
	const lastToAct = state.toAct.length <= 1;
	const drawStrength = (draws.comboDraw ? .22 : 0) + (draws.flushDraw ? .16 : 0) + (draws.oesd ? .12 : 0) + (draws.gutshot ? .05 : 0);
	if (facing) {
		if ((strength > .78 || strength > .62 && stackSpr < 2.2) && (legal.canRaise || legal.canAllIn)) {
			if (stackSpr <= 2.4 || bucket === "nuts") return shove(legal, me);
			return raiseTo(legal, betSize(state, me, pers.polar, texture.wet, state.street), me);
		}
		if (eq >= odds + (pers.sticky > .4 ? -.02 : .04) || bucket === "strong" || bucket === "nuts") return passive(legal);
		if (drawStrength > .15 && eq + drawStrength * .5 >= odds - .03) {
			if (draws.comboDraw && pers.aggression > .65 && rng() < pers.bluff + .15 && legal.canRaise) return raiseTo(legal, betSize(state, me, pers.polar, true, state.street), me);
			return passive(legal);
		}
		if (lastToAct && texture.dry && pers.bluff > .2 && rng() < pers.bluff * (state.street === "river" ? .35 : .5) && toCall < pot * .7 && (legal.canRaise || legal.canAllIn)) return raiseTo(legal, betSize(state, me, pers.polar, false, state.street), me);
		if (bucket === "top-pair" && rng() < pers.sticky && legal.canCall && odds <= .42) return {
			kind: "call",
			amount: legal.callAmount
		};
		if (legal.canCheck) return { kind: "check" };
		return { kind: "fold" };
	}
	if ((strength > .55 || texture.dry && lastToAct && rng() < pers.aggression || drawStrength > .18 && rng() < pers.aggression || bucket === "air" && texture.dry && lastToAct && rng() < pers.bluff) && (legal.canBet || legal.canAllIn)) {
		if (bucket === "nuts" && stackSpr < 1.6) return shove(legal, me);
		const to = betSize(state, me, pers.polar, texture.wet, state.street);
		if (legal.canBet) {
			const amount = Math.min(legal.maxTo, Math.max(legal.minBet, to));
			if (amount >= me.stack && legal.canAllIn) return shove(legal, me);
			return {
				kind: "bet",
				amount
			};
		}
		return shove(legal, me);
	}
	if (legal.canCheck) return { kind: "check" };
	if (made && strength > .4 && legal.canCall) return {
		kind: "call",
		amount: legal.callAmount
	};
	return pick(rng, { kind: "check" }, { kind: "fold" }, legal.canCheck ? 1 : 0);
}
function aiDelayMs(state) {
	const speed = state.config.speed;
	const base = speed === "fast" ? 420 : speed === "slow" ? 1400 : 780;
	const legal = legalActions(state);
	const big = legal.callAmount > potTotal(state) * .5 || legal.minRaiseTo > potTotal(state);
	const spread = big ? 900 : 420;
	const jitter = (state.handId * 17 + (state.actorId?.length ?? 1) * 13) % spread - spread / 4;
	return Math.max(280, base + jitter + (state.config.difficulty === "pro" && big ? 400 : 0));
}
var KEY = "felt-save-v1";
var DEFAULT_SAVE = {
	version: 1,
	name: "You",
	bankroll: 5e4,
	settings: {
		difficulty: "pro",
		speed: "normal",
		seats: 6,
		buyInBb: 100,
		smallBlind: 50,
		sound: true,
		autoMuck: true,
		showCoach: true,
		showHud: true
	},
	career: {
		hands: 0,
		net: 0,
		biggestPot: 0,
		busts: 0,
		tablesWon: 0
	}
};
function migrate(raw) {
	const s = {
		...DEFAULT_SAVE,
		...raw,
		version: 1
	};
	s.settings = {
		...DEFAULT_SAVE.settings,
		...raw.settings
	};
	s.career = {
		...DEFAULT_SAVE.career,
		...raw.career
	};
	if (!Number.isFinite(s.bankroll) || s.bankroll < 0) s.bankroll = DEFAULT_SAVE.bankroll;
	return s;
}
function loadSave() {
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return structuredClone(DEFAULT_SAVE);
		return migrate(JSON.parse(raw));
	} catch {
		return structuredClone(DEFAULT_SAVE);
	}
}
function writeSave(save) {
	try {
		const prev = localStorage.getItem(KEY);
		if (prev) localStorage.setItem(`${KEY}.bak`, prev);
		localStorage.setItem(KEY, JSON.stringify({
			...save,
			version: 1
		}));
	} catch {}
}
function configFromSave(save) {
	return {
		seats: save.settings.seats,
		smallBlind: save.settings.smallBlind,
		bigBlind: save.settings.smallBlind * 2,
		buyInBb: save.settings.buyInBb,
		difficulty: save.settings.difficulty,
		speed: save.settings.speed,
		playerName: save.name,
		autoMuck: save.settings.autoMuck
	};
}
/** Procedural Web Audio SFX. Unlock on the first gesture. */
var ctx = null;
var master = null;
var sfx = null;
var enabled = true;
function ac() {
	if (typeof window === "undefined") return null;
	if (!ctx) {
		const C = window.AudioContext || window.webkitAudioContext;
		if (!C) return null;
		ctx = new C({ latencyHint: "interactive" });
		master = ctx.createGain();
		sfx = ctx.createGain();
		sfx.gain.value = .7;
		master.gain.value = .85;
		sfx.connect(master);
		master.connect(ctx.destination);
	}
	return ctx;
}
function setSoundEnabled(on) {
	enabled = on;
	if (master && ctx) master.gain.setTargetAtTime(on ? .85 : 0, ctx.currentTime, .02);
}
function unlockAudio() {
	const c = ac();
	if (c && c.state === "suspended") c.resume();
}
function resumeAudio() {
	if (ctx?.state === "suspended") ctx.resume();
}
function beep(freq, dur, type, gain = .08, slide) {
	if (!enabled) return;
	const c = ac();
	if (!c || !sfx) return;
	if (c.state === "suspended") return;
	const osc = c.createOscillator();
	const g = c.createGain();
	osc.type = type;
	osc.frequency.setValueAtTime(freq, c.currentTime);
	if (slide) osc.frequency.exponentialRampToValueAtTime(Math.max(40, freq * slide), c.currentTime + dur);
	g.gain.setValueAtTime(1e-4, c.currentTime);
	g.gain.exponentialRampToValueAtTime(gain, c.currentTime + .012);
	g.gain.exponentialRampToValueAtTime(1e-4, c.currentTime + dur);
	osc.connect(g);
	g.connect(sfx);
	osc.start();
	osc.stop(c.currentTime + dur + .02);
	osc.onended = () => {
		osc.disconnect();
		g.disconnect();
	};
}
function noise(dur, gain = .04, hp = 800) {
	if (!enabled) return;
	const c = ac();
	if (!c || !sfx) return;
	if (c.state === "suspended") return;
	const n = c.createBuffer(1, Math.floor(c.sampleRate * dur), c.sampleRate);
	const data = n.getChannelData(0);
	for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
	const src = c.createBufferSource();
	src.buffer = n;
	const f = c.createBiquadFilter();
	f.type = "highpass";
	f.frequency.value = hp;
	const g = c.createGain();
	g.gain.setValueAtTime(gain, c.currentTime);
	g.gain.exponentialRampToValueAtTime(1e-4, c.currentTime + dur);
	src.connect(f);
	f.connect(g);
	g.connect(sfx);
	src.start();
	src.stop(c.currentTime + dur);
}
var sfxPlay = {
	deal: () => {
		noise(.05, .035, 1200);
		beep(420 + Math.random() * 40, .06, "triangle", .03);
	},
	chip: () => beep(180 + Math.random() * 40, .07, "square", .04, .7),
	check: () => beep(520, .05, "sine", .03),
	fold: () => {
		noise(.08, .03, 600);
		beep(220, .1, "sine", .04, .5);
	},
	raise: () => {
		beep(340, .09, "triangle", .05, 1.4);
		beep(510, .12, "sine", .03);
	},
	allin: () => {
		beep(160, .18, "sawtooth", .05, 2.2);
		beep(480, .16, "triangle", .04);
	},
	win: () => {
		beep(523, .12, "sine", .05);
		setTimeout(() => beep(659, .12, "sine", .05), 90);
		setTimeout(() => beep(784, .18, "sine", .05), 180);
	},
	lose: () => beep(196, .22, "sine", .04, .6),
	click: () => beep(760, .03, "square", .02)
};
var toastSeq = 1;
function persist(save) {
	writeSave(save);
}
function applyCareer(save, game, extra) {
	game.players.find((p) => p.id === "hero");
	const pot = game.result?.pots.reduce((s, p) => s + p.amount, 0) ?? 0;
	const career = {
		...save.career,
		hands: save.career.hands + (game.phase === "showdown" ? 1 : 0),
		biggestPot: Math.max(save.career.biggestPot, pot),
		...extra
	};
	const bankroll = save.bankroll;
	return {
		...save,
		career,
		bankroll
	};
}
function talkFor(action, name, personalityId) {
	const pers = PERSONALITIES.find((p) => p.id === personalityId);
	if (!pers || pers.talk < .15) {
		if (action.kind === "allin") return `${name}: All-in.`;
		return null;
	}
	const key = action.kind === "bet" || action.kind === "raise" ? "raise" : action.kind;
	const band = pers.talk > .4 ? "high" : pers.talk > .2 ? "mid" : "low";
	const pool = LINES[key]?.[band] ?? LINES[key]?.low ?? [];
	if (!pool.length) return null;
	if (Math.random() > pers.talk + .25) return null;
	return `${name}: ${pool[Math.floor(Math.random() * pool.length)]}`;
}
function sfxFor(kind) {
	if (kind === "fold") sfxPlay.fold();
	else if (kind === "check") sfxPlay.check();
	else if (kind === "call" || kind === "bet") sfxPlay.chip();
	else if (kind === "raise") sfxPlay.raise();
	else if (kind === "allin") sfxPlay.allin();
}
var useFelt = create((set, get) => ({
	game: newLobby(),
	save: loadSave(),
	toast: null,
	betTo: 0,
	showCoach: true,
	showLog: false,
	showHud: true,
	showMenu: false,
	showRules: false,
	dealingKey: 0,
	hydrate: () => {
		const save = loadSave();
		setSoundEnabled(save.settings.sound);
		set({
			save,
			showCoach: save.settings.showCoach,
			showHud: save.settings.showHud
		});
	},
	setName: (name) => {
		const save = {
			...get().save,
			name: name.slice(0, 16)
		};
		persist(save);
		set({ save });
	},
	patchSettings: (p) => {
		const save = {
			...get().save,
			settings: {
				...get().save.settings,
				...p
			}
		};
		persist(save);
		setSoundEnabled(save.settings.sound);
		set({
			save,
			showCoach: save.settings.showCoach,
			showHud: save.settings.showHud
		});
	},
	startTable: (cfg) => {
		unlockAudio();
		const { save } = get();
		const merged = {
			...configFromSave(save),
			...cfg,
			playerName: save.name
		};
		const buy = (merged.buyInBb ?? 100) * (merged.bigBlind ?? (merged.smallBlind ?? 50) * 2);
		if (save.bankroll < buy) {
			const topped = {
				...save,
				bankroll: Math.max(save.bankroll, buy * 3)
			};
			persist(topped);
			set({ save: topped });
		}
		const current = get().save;
		const nextBank = current.bankroll - buy;
		const nextSave = {
			...current,
			bankroll: Math.max(0, nextBank)
		};
		persist(nextSave);
		const game = sitDown(newLobby(merged));
		sfxPlay.deal();
		set({
			save: nextSave,
			game,
			dealingKey: get().dealingKey + 1,
			showMenu: false,
			betTo: merged.bigBlind ?? 100
		});
	},
	humanAct: (action) => {
		const { game } = get();
		if (game.phase !== "acting" || game.actorId !== "hero") return;
		const next = applyAction(game, action);
		sfxFor(action.kind);
		set({
			game: next,
			toast: null
		});
	},
	setBetTo: (n) => set({ betTo: Math.max(0, Math.round(n)) }),
	tick: () => {
		const { game } = get();
		if (game.phase === "dealing") {
			const next = beginActing(game);
			sfxPlay.deal();
			const legal = legalActions(next);
			set({
				game: next,
				dealingKey: get().dealingKey + 1,
				betTo: legal.minRaiseTo || legal.minBet || next.config.bigBlind
			});
			return;
		}
		if (game.phase === "runout") {
			sfxPlay.deal();
			const next = dealNextStreet(game);
			const legal = legalActions(next);
			set({
				game: next,
				dealingKey: get().dealingKey + 1,
				betTo: legal.minRaiseTo || legal.minBet || next.config.bigBlind
			});
			return;
		}
		if (game.phase === "acting" && game.actorId && game.actorId !== "hero") {
			const action = chooseAction(game, (game.rngSeed ^ game.log.length * 9973) >>> 0 || 1);
			const actor = game.players.find((p) => p.id === game.actorId);
			let next = applyAction(game, action);
			if (next.log.length === game.log.length) next = applyAction(game, legalActions(game).canCheck ? { kind: "check" } : { kind: "fold" });
			sfxFor(action.kind);
			const line = actor ? talkFor(action, actor.name, actor.personalityId) : null;
			const toast = line ? {
				id: toastSeq++,
				text: line,
				name: actor?.name ?? ""
			} : get().toast;
			const legal = legalActions(next);
			set({
				game: next,
				toast,
				betTo: legal.minRaiseTo || legal.minBet || next.config.bigBlind
			});
			return;
		}
		if (game.phase === "showdown") {
			const hero = game.players.find((p) => p.id === "hero");
			const start = game.lastStartStacks.hero ?? hero?.stack ?? 0;
			const delta = (hero?.stack ?? 0) - start;
			if (delta > 0) sfxPlay.win();
			else if (delta < 0) sfxPlay.lose();
			const save = applyCareer(get().save, game);
			persist(save);
			set({
				save,
				game: concludeShowdown(game)
			});
			return;
		}
		if (game.phase === "between") {
			const next = nextHand(game);
			sfxPlay.deal();
			set({
				game: next,
				dealingKey: get().dealingKey + 1,
				toast: null
			});
		}
	},
	skipToNext: () => {
		const { game } = get();
		if (game.phase === "showdown") get().tick();
		if (get().game.phase === "between") get().tick();
	},
	rebuy: () => {
		const { game, save } = get();
		const buy = game.config.buyInBb * game.config.bigBlind;
		if (save.bankroll < buy) {
			const topped = {
				...save,
				bankroll: buy * 4,
				career: {
					...save.career,
					busts: save.career.busts + 1
				}
			};
			persist(topped);
			set({
				save: topped,
				game: rebuyHero(game),
				dealingKey: get().dealingKey + 1
			});
			return;
		}
		const nextSave = {
			...save,
			bankroll: save.bankroll - buy,
			career: {
				...save.career,
				busts: save.career.busts + 1
			}
		};
		persist(nextSave);
		set({
			save: nextSave,
			game: rebuyHero(game),
			dealingKey: get().dealingKey + 1
		});
	},
	cashOut: () => {
		const { game, save } = get();
		const hero = game.players.find((p) => p.id === "hero");
		const stack = hero && !hero.busted ? hero.stack : 0;
		const nextSave = {
			...save,
			bankroll: save.bankroll + stack,
			career: {
				...save.career,
				net: save.career.net + (stack - game.config.buyInBb * game.config.bigBlind),
				tablesWon: save.career.tablesWon + (game.phase === "winner" ? 1 : 0)
			}
		};
		persist(nextSave);
		set({
			save: nextSave,
			game: newLobby(configFromSave(nextSave)),
			showMenu: false
		});
	},
	toggle: (k) => {
		const next = !get()[k];
		set({ [k]: next });
		if (k === "showCoach" || k === "showHud") get().patchSettings({ [k]: next });
	}
}));
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 font-medium transition-opacity transition-transform duration-(--motion-quick,150ms) disabled:pointer-events-none disabled:opacity-40 active:scale-[0.98] select-none", {
	variants: {
		variant: {
			primary: "bg-accent text-accent-fg hover:opacity-90",
			secondary: "bg-bg-subtle text-fg border border-border hover:border-border-strong",
			ghost: "text-fg-muted hover:text-fg hover:bg-bg-subtle",
			danger: "bg-danger text-fg hover:opacity-90",
			fold: "bg-bg-subtle text-fg border border-border hover:border-danger",
			call: "bg-accent text-accent-fg hover:opacity-90",
			raise: "bg-fg text-accent-fg hover:opacity-90"
		},
		size: {
			sm: "h-9 px-3 text-sm rounded-sm",
			md: "h-11 px-4 text-sm rounded-md",
			lg: "h-12 px-5 text-base rounded-md",
			xl: "h-14 px-6 text-base rounded-lg"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function Choice({ label, value, options, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
		className: "mb-2 text-xs uppercase tracking-[0.16em] text-fg-subtle",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-wrap gap-2",
		children: options.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => onChange(o.v),
			className: cn("rounded-md border px-3 py-2 text-left text-sm transition-colors", value === o.v ? "border-accent bg-accent text-accent-fg" : "border-border bg-bg-subtle text-fg hover:border-border-strong"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "font-medium",
				children: o.l
			}), o.d && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("text-[11px]", value === o.v ? "text-accent-fg/70" : "text-fg-muted"),
				children: o.d
			})]
		}, String(o.v)))
	})] });
}
function Lobby() {
	const save = useFelt((s) => s.save);
	const startTable = useFelt((s) => s.startTable);
	const setName = useFelt((s) => s.setName);
	const patchSettings = useFelt((s) => s.patchSettings);
	const s = save.settings;
	const buy = s.buyInBb * s.smallBlind * 2;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex min-h-dvh max-w-3xl flex-col justify-center gap-8 px-5 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.28em] text-fg-subtle",
						children: "Six-max cash"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-5xl font-medium tracking-[-0.04em] sm:text-7xl",
						children: "Felt"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-md text-pretty text-fg-muted",
						children: "Texas Hold'em with a Pro-mode AI that prices pot odds, SPR, position, and board texture. Sit down and play a real table."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-border bg-bg-elevated p-5 sm:p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-5 flex flex-wrap items-end justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mb-1 block text-xs uppercase tracking-[0.16em] text-fg-subtle",
								children: "Name"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: save.name,
								maxLength: 16,
								onChange: (e) => setName(e.target.value),
								className: "h-11 w-48 rounded-md border border-border bg-bg px-3 text-fg"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-right",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-[0.16em] text-fg-subtle",
								children: "Bankroll"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-mono text-lg tabular-nums",
								children: formatChips(save.bankroll)
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								label: "AI",
								value: s.difficulty,
								onChange: (v) => patchSettings({ difficulty: v }),
								options: [
									{
										v: "casual",
										l: "Casual",
										d: "Leaky, sticky"
									},
									{
										v: "regular",
										l: "Regular",
										d: "Solid club"
									},
									{
										v: "pro",
										l: "Pro",
										d: "GTO-leaning"
									}
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								label: "Seats",
								value: s.seats,
								onChange: (v) => patchSettings({ seats: v }),
								options: [
									{
										v: 2,
										l: "Heads-up"
									},
									{
										v: 4,
										l: "4-max"
									},
									{
										v: 6,
										l: "6-max"
									}
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								label: "Buy-in",
								value: s.buyInBb,
								onChange: (v) => patchSettings({ buyInBb: v }),
								options: [
									{
										v: 50,
										l: "50 BB",
										d: formatChips(50 * s.smallBlind * 2)
									},
									{
										v: 100,
										l: "100 BB",
										d: formatChips(100 * s.smallBlind * 2)
									},
									{
										v: 200,
										l: "200 BB",
										d: formatChips(200 * s.smallBlind * 2)
									}
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								label: "Speed",
								value: s.speed,
								onChange: (v) => patchSettings({ speed: v }),
								options: [
									{
										v: "slow",
										l: "Slow"
									},
									{
										v: "normal",
										l: "Normal"
									},
									{
										v: "fast",
										l: "Fast"
									}
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						className: "mt-6 w-full",
						size: "xl",
						onClick: () => startTable(),
						disabled: save.bankroll < buy,
						children: ["Sit down · ", formatChips(buy)]
					}),
					save.bankroll < buy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-center text-xs text-fg-muted",
						children: "Bankroll short of this buy-in. Pick a smaller stack."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
				className: "grid grid-cols-2 gap-3 text-sm sm:grid-cols-4",
				children: [
					["Hands", save.career.hands],
					["Career", formatChips(save.career.net)],
					["Biggest pot", formatChips(save.career.biggestPot)],
					["Tables", save.career.tablesWon]
				].map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg border border-border bg-bg-elevated px-3 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-[11px] uppercase tracking-[0.14em] text-fg-subtle",
						children: k
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "font-mono tabular-nums",
						children: v
					})]
				}, k))
			})
		]
	});
}
var SIZE = {
	sm: "w-9 h-[3.25rem] text-[0.7rem] rounded-[6px]",
	md: "w-12 h-[4.25rem] text-sm rounded-[8px]",
	lg: "w-16 h-[5.6rem] text-base rounded-[10px]"
};
function PlayingCard({ card, hidden, win, size = "md", delay = 0, className }) {
	if (!card || hidden) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("card-back deal-card relative overflow-hidden", SIZE[size], className),
		style: { animationDelay: `${delay}ms` },
		"aria-label": "Facedown card",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-[5px] rounded-[5px] border border-accent/20" })
	});
	const red = isRed(card.suit);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("card-face deal-card relative flex flex-col justify-between p-1 leading-none", SIZE[size], win && "card-win", className),
		style: {
			animationDelay: `${delay}ms`,
			color: red ? "var(--color-suit-red)" : "var(--color-suit-ink)"
		},
		"aria-label": `${RANK_LABEL[card.rank]} of ${card.suit}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "font-display font-semibold tracking-tight",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: RANK_LABEL[card.rank] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "-mt-0.5",
				children: SUIT_GLYPH[card.suit]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "self-end rotate-180 font-display font-semibold",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: RANK_LABEL[card.rank] })
		})]
	});
}
function CardSlot({ size = "md" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: cn("border border-dashed border-fg/15 bg-black/10", SIZE[size], size === "lg" ? "rounded-[10px]" : "rounded-[8px]") });
}
function relativeSeats(game) {
	const heroIdx = game.players.findIndex((p) => p.isHuman);
	if (heroIdx < 0) return game.players;
	return [...game.players.slice(heroIdx), ...game.players.slice(0, heroIdx)];
}
function seatPos(i, n) {
	const a = Math.PI / 2 + i / n * Math.PI * 2;
	const rx = n <= 2 ? 0 : 42;
	const ry = n <= 2 ? i === 0 ? 40 : -38 : 39;
	const x = 50 + rx * Math.cos(a);
	const y = 50 + (n <= 2 ? i === 0 ? 40 : 12 : ry * Math.sin(a));
	return {
		left: `${x}%`,
		top: `${y}%`
	};
}
function hudLine(game, id) {
	const st = game.playerStats[id];
	if (!st || st.hands < 3) return null;
	return `${Math.round(st.vpip / st.hands * 100)}/${Math.round(st.pfr / st.hands * 100)}`;
}
function Seat({ player, game, style, showHud }) {
	const acting = game.actorId === player.id && game.phase === "acting";
	const pers = PERSONALITIES.find((p) => p.id === player.personalityId);
	const role = positionName(game, player.seat);
	const isBtn = game.button === player.seat;
	const shown = game.result?.shown.find((s) => s.playerId === player.id);
	const winner = new Set(game.result?.pots.flatMap((p) => p.winnerIds) ?? []).has(player.id);
	const reveal = player.isHuman || player.showed || !!shown;
	const hole = player.hole ?? [];
	const madeFive = player.isHuman && game.board.length >= 3 && hole.length === 2 ? bestHand(hole, game.board)?.five ?? [] : [];
	const fiveIds = new Set((shown?.five ?? madeFive).map((c) => `${c.rank}${c.suit}`));
	const hud = showHud && !player.isHuman ? hudLine(game, player.id) : null;
	const dim = player.folded || player.busted;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("absolute z-10 flex w-36 -translate-x-1/2 -translate-y-1/2 flex-col items-center gap-1 sm:w-44", dim && "opacity-45"),
		style,
		children: [
			!player.isHuman && hole.length === 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayingCard, {
					card: hole[0],
					hidden: !reveal,
					win: winner && fiveIds.has(`${hole[0].rank}${hole[0].suit}`),
					size: "sm",
					delay: 40
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayingCard, {
					card: hole[1],
					hidden: !reveal,
					win: winner && fiveIds.has(`${hole[1].rank}${hole[1].suit}`),
					size: "sm",
					delay: 90
				})]
			}),
			player.betStreet > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-full bg-bg-elevated/90 px-2 py-0.5 font-mono text-[11px] tabular-nums text-accent",
				children: formatChips(player.betStreet)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("relative flex w-full items-center gap-2 rounded-lg border bg-bg-elevated/90 px-2 py-1.5", acting ? "border-accent" : "border-border", winner && "border-accent"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("grid size-8 shrink-0 place-items-center rounded-full text-xs font-semibold", pers?.tone === "clay" && "bg-danger/30", pers?.tone === "pine" && "bg-felt", pers?.tone === "mist" && "bg-chip-blue/50", pers?.tone === "ink" && "bg-bg-subtle", pers?.tone === "bone" && "bg-accent text-accent-fg", player.isHuman && "bg-fg text-accent-fg"),
					children: (player.name[0] ?? "?").toUpperCase()
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-xs font-medium",
							children: player.name
						}), isBtn && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "dealer-btn",
							children: "D"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-mono text-[11px] tabular-nums text-fg-muted",
						children: [player.busted ? "Out" : formatChips(player.stack), player.allIn && !player.busted ? " · all-in" : ""]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-1 text-[10px] uppercase tracking-wider text-fg-subtle",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: role }),
					hud && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono normal-case tracking-normal text-fg-muted",
						children: hud
					}),
					acting && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-accent",
						children: "act"
					})
				]
			})
		]
	});
}
function TableView({ game, showHud }) {
	const seats = relativeSeats(game);
	const n = seats.length;
	const pot = potTotal(game);
	const hero = game.players.find((p) => p.isHuman);
	const heroShown = game.result?.shown.find((s) => s.playerId === "hero");
	const winIds = new Set(game.result?.pots.flatMap((p) => p.winnerIds) ?? []);
	const heroFive = new Set((heroShown?.five ?? (hero?.hole && game.board.length >= 3 ? bestHand(hero.hole, game.board)?.five : void 0) ?? []).map((c) => `${c.rank}${c.suit}`));
	const made = hero?.hole && game.board.length >= 3 && !hero.folded ? bestHand(hero.hole, game.board)?.name : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "felt-table",
		children: [seats.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Seat, {
			player: p,
			game,
			showHud,
			style: seatPos(i, n)
		}, p.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "absolute left-1/2 top-[46%] flex w-[78%] -translate-x-1/2 -translate-y-1/2 flex-col items-center gap-3 sm:top-[44%]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-mono text-[11px] uppercase tracking-[0.18em] text-fg-subtle",
							children: [game.street, game.handId ? ` · #${game.handId}` : ""]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-2xl font-medium tabular-nums text-accent sm:text-3xl",
							children: formatChips(pot)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-[11px] text-fg-muted",
							children: formatBb(pot, game.config.bigBlind)
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center justify-center gap-1 sm:gap-2",
					children: Array.from({ length: 5 }).map((_, i) => {
						const c = game.board[i];
						if (!c) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardSlot, { size: n <= 2 ? "md" : "md" }, i);
						const win = winIds.size > 0 && heroFive.has(`${c.rank}${c.suit}`) && winIds.has("hero");
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayingCard, {
							card: c,
							size: "md",
							delay: i * 80,
							win
						}, `${c.rank}${c.suit}${i}`);
					})
				}),
				made && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-fg-muted",
					children: made
				}),
				game.result?.uncontested && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-fg-muted",
					children: [game.players.find((p) => p.id === game.result?.uncontested)?.name, " takes it"]
				})
			]
		})]
	});
}
function ActionBar() {
	const game = useFelt((s) => s.game);
	const betTo = useFelt((s) => s.betTo);
	const setBetTo = useFelt((s) => s.setBetTo);
	const humanAct = useFelt((s) => s.humanAct);
	const skipToNext = useFelt((s) => s.skipToNext);
	const heroTurn = game.phase === "acting" && game.actorId === "hero";
	const legal = (0, import_react.useMemo)(() => legalActions(game), [game]);
	const pot = potTotal(game);
	(0, import_react.useEffect)(() => {
		if (!heroTurn) return;
		const start = legal.minRaiseTo || legal.minBet || game.config.bigBlind;
		setBetTo(start);
	}, [
		heroTurn,
		game.handId,
		game.street,
		game.currentBet,
		legal.minBet,
		legal.minRaiseTo,
		game.config.bigBlind,
		setBetTo
	]);
	(0, import_react.useEffect)(() => {
		if (!heroTurn) return;
		const t = window.setTimeout(() => {
			if (legal.canCheck) humanAct({ kind: "check" });
			else humanAct({ kind: "fold" });
		}, 16e3);
		return () => window.clearTimeout(t);
	}, [
		heroTurn,
		game.handId,
		game.street,
		game.log.length,
		humanAct,
		legal.canCheck
	]);
	if (game.phase === "showdown" || game.phase === "between") {
		const delta = (game.players.find((p) => p.id === "hero")?.stack ?? 0) - (game.lastStartStacks.hero ?? 0);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col items-center gap-3",
			children: [game.phase === "showdown" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: cn("font-mono text-sm tabular-nums", delta >= 0 ? "text-good" : "text-danger"),
				children: [
					delta >= 0 ? "+" : "",
					formatChips(delta),
					" this hand"
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "primary",
				size: "lg",
				className: "min-w-44",
				onClick: skipToNext,
				children: "Next hand"
			})]
		});
	}
	if (game.phase === "busted") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-center text-sm text-fg-muted",
		children: "Stack is gone. Rebuy or cash out from the header."
	});
	if (game.phase === "winner") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-center text-sm text-fg-muted",
		children: "Table is yours. Cash out whenever you like."
	});
	if (!heroTurn) {
		const actor = game.players.find((p) => p.id === game.actorId);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-center text-sm text-fg-muted",
			children: game.phase === "acting" && actor ? `${actor.name} is acting` : "Dealing"
		});
	}
	const presets = [
		{
			label: "1/3",
			v: Math.floor(pot / 3)
		},
		{
			label: "1/2",
			v: Math.floor(pot / 2)
		},
		{
			label: "2/3",
			v: Math.floor(pot * 2 / 3)
		},
		{
			label: "Pot",
			v: pot
		},
		{
			label: "All-in",
			v: legal.maxTo - (game.players.find((p) => p.id === "hero")?.betStreet ?? 0)
		}
	];
	const isRaise = legal.callAmount > 0;
	const min = isRaise ? legal.minRaiseTo : legal.minBet;
	const max = legal.maxTo;
	const callLabel = legal.canCheck ? "Check" : `Call ${formatChips(legal.callAmount)}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto w-full max-w-xl space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "timebank",
				"aria-hidden": true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}, `${game.handId}-${game.street}-${game.log.length}`)
			}),
			(legal.canBet || legal.canRaise) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg border border-border bg-bg-elevated p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 flex items-center justify-between text-xs text-fg-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isRaise ? "Raise to" : "Bet" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono tabular-nums text-fg",
							children: formatChips(betTo)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "range",
						min,
						max,
						step: game.config.smallBlind,
						value: Math.min(max, Math.max(min, betTo)),
						onChange: (e) => setBetTo(Number(e.target.value)),
						className: "w-full accent-accent"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 flex flex-wrap gap-1.5",
						children: presets.map((p) => {
							const to = isRaise ? Math.min(max, Math.max(min, game.currentBet + p.v)) : Math.min(max, Math.max(min, p.v));
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "h-8 rounded-sm border border-border px-2 text-[11px] text-fg-muted hover:text-fg",
								onClick: () => setBetTo(p.label === "All-in" ? max : to),
								children: p.label
							}, p.label);
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "fold",
						size: "xl",
						className: "min-h-12",
						onClick: () => humanAct({ kind: "fold" }),
						children: "Fold"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "call",
						size: "xl",
						className: "min-h-12",
						onClick: () => humanAct({
							kind: legal.canCheck ? "check" : "call",
							amount: legal.callAmount
						}),
						disabled: !legal.canCheck && !legal.canCall,
						children: callLabel
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "raise",
						size: "xl",
						className: "min-h-12",
						onClick: () => {
							if (betTo >= max || !legal.canRaise && !legal.canBet && legal.canAllIn) {
								humanAct({ kind: "allin" });
								return;
							}
							humanAct({
								kind: isRaise ? "raise" : "bet",
								amount: betTo
							});
						},
						disabled: !legal.canBet && !legal.canRaise && !legal.canAllIn,
						children: betTo >= max ? "All-in" : isRaise ? "Raise" : "Bet"
					})
				]
			})
		]
	});
}
function coachReport(state) {
	const hero = state.players.find((p) => p.id === "hero");
	if (!hero?.hole || hero.hole.length < 2) return null;
	const legal = legalActions(state, state.actorId === "hero" ? "hero" : void 0);
	const toCall = state.actorId === "hero" ? legal.callAmount : Math.max(0, state.currentBet - hero.betStreet);
	const pot = potTotal(state);
	const nOpp = Math.max(1, state.players.filter((p) => !p.folded && !p.busted && p.id !== "hero").length);
	const board = state.board;
	const made = board.length >= 3 ? bestHand(hero.hole, board) : null;
	const draws = board.length >= 3 ? drawInfo(hero.hole, board) : null;
	const texture = analyzeBoard(board);
	const eq = board.length >= 3 ? monteCarloEquity(hero.hole, board, nOpp, 140, (state.rngSeed ^ 2654435769) >>> 0 || 1) : monteCarloEquity(hero.hole, [], nOpp, 100, (state.rngSeed ^ 2246822507) >>> 0 || 1);
	const odds = potOdds(toCall, pot);
	const stackSpr = spr(hero.stack, Math.max(1, pot));
	const bucket = board.length >= 3 ? madeBucket(hero.hole, board) : "air";
	const pos = positionName(state, hero.seat);
	const drawLabels = [];
	if (draws?.flushDraw) drawLabels.push(`Flush draw (${draws.flushOuts} outs)`);
	if (draws?.oesd) drawLabels.push("Open-ended straight");
	if (draws?.gutshot) drawLabels.push("Gutshot");
	if (draws?.comboDraw) drawLabels.push("Combo draw");
	if (draws && draws.overcards) drawLabels.push(`${draws.overcards} overcard${draws.overcards > 1 ? "s" : ""}`);
	const tex = [];
	if (texture.dry) tex.push("Dry");
	if (texture.wet) tex.push("Wet");
	if (texture.paired) tex.push("Paired");
	if (texture.monotone) tex.push("Monotone");
	if (texture.twoTone) tex.push("Two-tone");
	if (texture.connected) tex.push("Connected");
	if (texture.broadwayHeavy) tex.push("Broadway");
	const advice = advise({
		eq: eq.equity,
		odds,
		toCall,
		bucket,
		draws: drawLabels,
		spr: stackSpr,
		canCheck: legal.canCheck,
		street: state.street,
		pos
	});
	return {
		hole: describeHole(hero.hole) || holeLabel(hero.hole[0], hero.hole[1]),
		made: made?.name ?? "Preflop",
		bucket,
		position: pos,
		street: state.street,
		pot,
		toCall,
		potOdds: odds,
		spr: stackSpr,
		equity: eq.equity,
		outs: draws?.outs ?? 0,
		draws: drawLabels,
		texture: tex,
		advice,
		samples: eq.samples
	};
}
function advise(a) {
	if (a.toCall <= 0) {
		if (a.bucket === "nuts" || a.bucket === "strong") return a.spr < 2 ? "Nut advantage, short SPR — look to get it in." : "Strong made hand. Bet for value; size up on wet textures.";
		if (a.draws.length) return `Equity ${pct(a.eq)} with draws. ${a.pos === "BTN" || a.pos === "CO" ? "In position, a stab is reasonable." : "Out of position, checking and realizing is cleaner."}`;
		if (a.eq > .55) return "Range advantage. A continuation bet keeps you in the driver's seat.";
		return a.canCheck ? "No initiative. Check and keep the pot small unless the board is excellent for a bluff." : "Proceed carefully.";
	}
	if (a.eq >= a.odds + .08) return `Getting the right price (${pct(a.odds)} pot odds vs ${pct(a.eq)} equity). Call, or raise for value if they are capped.`;
	if (a.eq >= a.odds - .02 && a.draws.length) return `Drawing with ${pct(a.eq)} equity, need about ${pct(a.odds)}. Call if implied odds are there.`;
	if (a.bucket === "top-pair" && a.odds <= .35) return "Top pair, modest ask. Call and reassess the next street.";
	if (a.eq < a.odds - .08 && a.bucket === "air") return `Behind (${pct(a.eq)} vs ${pct(a.odds)} needed). Fold unless you have a specific bluff.`;
	return `Close spot. Equity ${pct(a.eq)}, pot odds ${pct(a.odds)}, SPR ${a.spr.toFixed(1)}. Prefer the line that keeps your range balanced.`;
}
function pct(n) {
	return `${Math.round(n * 100)}%`;
}
function CoachPanel() {
	const game = useFelt((s) => s.game);
	const report = (0, import_react.useMemo)(() => coachReport(game), [
		game.handId,
		game.street,
		game.board,
		game.currentBet,
		game.actorId,
		game.phase
	]);
	if (!report) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-fg-muted",
		children: "Hole cards land after the deal."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 text-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-baseline justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xl",
					children: report.hole
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-wider text-fg-subtle",
					children: report.position
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-fg-muted",
				children: report.made
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "grid grid-cols-2 gap-2 font-mono text-xs tabular-nums",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						k: "Equity",
						v: `${Math.round(report.equity * 100)}%`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						k: "Pot odds",
						v: report.toCall ? `${Math.round(report.potOdds * 100)}%` : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						k: "SPR",
						v: report.spr.toFixed(1)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						k: "Outs",
						v: String(report.outs)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						k: "Pot",
						v: formatChips(report.pot)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						k: "To call",
						v: report.toCall ? formatChips(report.toCall) : "—"
					})
				]
			}),
			report.draws.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-fg-muted",
				children: report.draws.join(" · ")
			}),
			report.texture.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-fg-subtle",
				children: report.texture.join(" · ")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-pretty text-fg",
				children: report.advice
			})
		]
	});
}
function Row({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-sm bg-bg-subtle px-2 py-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-[10px] uppercase tracking-wider text-fg-subtle",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: v })]
	});
}
function LogPanel() {
	const rows = useFelt((s) => s.game.log).slice(-18).reverse();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
		className: "space-y-1.5 font-mono text-[11px] leading-snug text-fg-muted",
		children: rows.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "text-fg-subtle",
			children: [r.street.slice(0, 1).toUpperCase(), " "]
		}), r.text] }, `${r.handId}-${i}-${r.text}`))
	});
}
function HudPanel() {
	const game = useFelt((s) => s.game);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overflow-x-auto",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "w-full text-left text-xs",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
				className: "text-[10px] uppercase tracking-wider text-fg-subtle",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-1 font-medium",
						children: "Seat"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-1 font-medium",
						children: "VPIP"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-1 font-medium",
						children: "PFR"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-1 font-medium",
						children: "3B"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-1 font-medium",
						children: "AF"
					})
				] })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
				className: "font-mono tabular-nums",
				children: game.players.map((p) => {
					const st = game.playerStats[p.id];
					const n = st?.hands || 0;
					const pct = (x) => n ? Math.round(x / n * 100) : 0;
					const af = st && st.calls + st.aggro ? (st.aggro / Math.max(1, st.calls)).toFixed(1) : "—";
					const pers = PERSONALITIES.find((x) => x.id === p.personalityId);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-border",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "py-1.5",
								children: [p.name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-[10px] text-fg-subtle",
									children: pers?.tagline ?? "You"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: pct(st?.vpip ?? 0) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: pct(st?.pfr ?? 0) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: pct(st?.threeBet ?? 0) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: af })
						]
					}, p.id);
				})
			})]
		})
	});
}
function RulesSheet({ open, onClose }) {
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 grid place-items-end sm:place-items-center bg-black/55 p-4",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-h-[86dvh] w-full max-w-lg overflow-y-auto rounded-xl border border-border bg-bg-elevated p-5",
			onClick: (e) => e.stopPropagation(),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "How this table plays"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "sm",
					onClick: onClose,
					children: "Close"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 text-sm text-pretty text-fg-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "No-limit Texas Hold'em. Two hole cards, then flop, turn, river. Best five-card hand wins." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Action is fold, check, call, bet, raise, or all-in. Min-raise equals the last full raise. A short all-in does not reopen for players who already acted." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Side pots form when someone is all-in for less. Uncalled bets come back. Odd chips on a split go left of the button." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Hand ranks: high card, pair, two pair, trips, straight, flush, full house, quads, straight flush. Wheel is A-2-3-4-5. Ace-high straight flush is a royal." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Pro AI uses Chen preflop ranges, Monte Carlo equity, pot odds, SPR, and board texture. Personalities still leak: Vesper is the tough TAG, Juno prints pressure, Nadir waits for premiums." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Keys: F fold, C check/call, R bet/raise, A all-in, N next hand. Time bank auto-checks or folds at 16s." })
				]
			})]
		})
	});
}
function MenuSheet() {
	const open = useFelt((s) => s.showMenu);
	const toggle = useFelt((s) => s.toggle);
	const cashOut = useFelt((s) => s.cashOut);
	const rebuy = useFelt((s) => s.rebuy);
	const patch = useFelt((s) => s.patchSettings);
	const save = useFelt((s) => s.save);
	const game = useFelt((s) => s.game);
	if (!open) return null;
	const hero = game.players.find((p) => p.id === "hero");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 grid place-items-center bg-black/55 p-4",
		onClick: () => toggle("showMenu"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-sm space-y-4 rounded-xl border border-border bg-bg-elevated p-5",
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Table"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-mono text-sm tabular-nums text-fg-muted",
					children: [
						"Stack ",
						formatChips(hero?.stack ?? 0),
						" · ",
						formatBb(hero?.stack ?? 0, game.config.bigBlind)
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center justify-between text-sm",
					children: ["Sound", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: save.settings.sound,
						onChange: (e) => patch({ sound: e.target.checked })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center justify-between text-sm",
					children: ["Coach", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: save.settings.showCoach,
						onChange: () => toggle("showCoach")
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center justify-between text-sm",
					children: ["HUD", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: save.settings.showHud,
						onChange: () => toggle("showHud")
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-2 pt-2",
					children: [
						(game.phase === "busted" || hero && hero.stack < game.config.bigBlind * 10 && !hero.busted) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							onClick: rebuy,
							children: "Rebuy"
						}),
						game.phase === "busted" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "primary",
							onClick: rebuy,
							children: ["Rebuy ", formatChips(game.config.buyInBb * game.config.bigBlind)]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							onClick: cashOut,
							children: "Cash out"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: () => toggle("showRules"),
							children: "Rules"
						})
					]
				})
			]
		})
	});
}
function GameApp() {
	const game = useFelt((s) => s.game);
	const save = useFelt((s) => s.save);
	const toast = useFelt((s) => s.toast);
	const showCoach = useFelt((s) => s.showCoach);
	const showLog = useFelt((s) => s.showLog);
	const showHud = useFelt((s) => s.showHud);
	const showRules = useFelt((s) => s.showRules);
	const hydrate = useFelt((s) => s.hydrate);
	const toggle = useFelt((s) => s.toggle);
	const humanAct = useFelt((s) => s.humanAct);
	const skipToNext = useFelt((s) => s.skipToNext);
	const betTo = useFelt((s) => s.betTo);
	(0, import_react.useEffect)(() => {
		hydrate();
	}, [hydrate]);
	(0, import_react.useEffect)(() => {
		const onVis = () => {
			if (document.visibilityState === "visible") resumeAudio();
		};
		document.addEventListener("visibilitychange", onVis);
		const onFirst = () => unlockAudio();
		window.addEventListener("pointerdown", onFirst, { once: true });
		window.addEventListener("keydown", onFirst, { once: true });
		return () => {
			document.removeEventListener("visibilitychange", onVis);
		};
	}, []);
	const phase = game.phase;
	const actorId = game.actorId;
	const handId = game.handId;
	const street = game.street;
	const logLen = game.log.length;
	const boardLen = game.board.length;
	(0, import_react.useEffect)(() => {
		if (phase === "lobby") return;
		let delay = 0;
		if (phase === "dealing") delay = 880;
		else if (phase === "runout") delay = 640;
		else if (phase === "acting" && actorId && actorId !== "hero") delay = aiDelayMs(game);
		else if (phase === "showdown") delay = 2400;
		else if (phase === "between") delay = 1200;
		else return;
		const t = window.setTimeout(() => useFelt.getState().tick(), delay);
		return () => window.clearTimeout(t);
	}, [
		phase,
		actorId,
		handId,
		street,
		logLen,
		boardLen,
		game
	]);
	(0, import_react.useEffect)(() => {
		function onKey(e) {
			const tag = e.target?.tagName;
			if (tag === "INPUT" || tag === "TEXTAREA") return;
			const g = useFelt.getState().game;
			const k = e.key.toLowerCase();
			if (k === "n") {
				skipToNext();
				return;
			}
			if (g.phase !== "acting" || g.actorId !== "hero") return;
			const legal = legalActions(g);
			if (k === "f") humanAct({ kind: "fold" });
			if (k === "c") humanAct({
				kind: legal.canCheck ? "check" : "call",
				amount: legal.callAmount
			});
			if (k === "r") {
				const raise = legal.callAmount > 0;
				if (!legal.canBet && !legal.canRaise && legal.canAllIn) humanAct({ kind: "allin" });
				else humanAct({
					kind: raise ? "raise" : "bet",
					amount: useFelt.getState().betTo
				});
			}
			if (k === "a") humanAct({ kind: "allin" });
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [
		humanAct,
		skipToNext,
		betTo
	]);
	if (game.phase === "lobby") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lobby, {});
	const hero = game.players.find((p) => p.isHuman);
	const hole = hero?.hole ?? [];
	const session = game.sessionNet;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "felt-shell flex min-h-dvh flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between gap-3 px-4 py-3 sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xl leading-none",
					children: "Felt"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-mono text-[11px] text-fg-muted",
					children: [
						game.config.smallBlind,
						"/",
						game.config.bigBlind,
						" · ",
						game.config.difficulty
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: cn("hidden font-mono text-xs tabular-nums sm:block", session >= 0 ? "text-good" : "text-danger"),
							children: [session >= 0 ? "+" : "", formatChips(session)]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-mono text-xs tabular-nums text-fg-muted",
							children: [formatChips(save.bankroll), " book"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
							label: "Coach",
							onClick: () => toggle("showCoach"),
							active: showCoach,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
							label: "Log",
							onClick: () => toggle("showLog"),
							active: showLog,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollText, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
							label: "Rules",
							onClick: () => toggle("showRules"),
							active: false,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
							label: "Menu",
							onClick: () => toggle("showMenu"),
							active: false,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-4" })
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid w-full max-w-6xl flex-1 grid-cols-1 gap-4 px-3 pb-4 lg:grid-cols-[1fr_280px]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 flex-col gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative px-1 pt-8 sm:pt-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableView, {
								game,
								showHud
							}), toast && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "pointer-events-none absolute left-1/2 top-2 z-20 -translate-x-1/2 rounded-md border border-border bg-bg-elevated px-3 py-1.5 text-sm",
								children: toast.text
							}, toast.id)]
						}),
						hole.length === 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayingCard, {
									card: hole[0],
									size: "lg",
									delay: 20
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayingCard, {
									card: hole[1],
									size: "lg",
									delay: 80
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-fg-subtle",
								children: hero?.folded ? "Folded" : "Your hand"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "px-1 pb-[max(0.5rem,env(safe-area-inset-bottom))]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionBar, {})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "space-y-3 lg:sticky lg:top-4 lg:self-start",
					children: [
						showCoach && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "rounded-xl border border-border bg-bg-elevated p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mb-3 text-xs uppercase tracking-[0.16em] text-fg-subtle",
								children: "Coach"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CoachPanel, {})]
						}),
						showHud && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "rounded-xl border border-border bg-bg-elevated p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mb-3 text-xs uppercase tracking-[0.16em] text-fg-subtle",
								children: "HUD"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HudPanel, {})]
						}),
						showLog && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "rounded-xl border border-border bg-bg-elevated p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mb-3 text-xs uppercase tracking-[0.16em] text-fg-subtle",
								children: "Action"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogPanel, {})]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuSheet, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RulesSheet, {
				open: showRules,
				onClose: () => toggle("showRules")
			})
		]
	});
}
function IconBtn({ children, onClick, active, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		type: "button",
		variant: "ghost",
		size: "sm",
		"aria-label": label,
		className: cn("size-10 p-0", active && "text-fg bg-bg-subtle"),
		onClick,
		children
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameApp, {});
}
//#endregion
export { Home as component };
